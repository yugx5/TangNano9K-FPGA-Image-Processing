
`timescale 1ns / 1ps

module rgb2gray (
    input  wire       clk,
    input  wire       rst_n,
    input  wire [7:0] rgb_r,
    input  wire [7:0] rgb_g,
    input  wire [7:0] rgb_b,
    input  wire       in_valid,
    output reg  [7:0] gray_out,
    output reg        out_valid
);

wire [15:0] r_mult;
wire [15:0] g_mult;
wire [15:0] b_mult;
wire [15:0] gray_sum;

assign r_mult = rgb_r * 8'd77;
assign g_mult = rgb_g * 8'd150;
assign b_mult = rgb_b * 8'd29;

assign gray_sum = r_mult + g_mult + b_mult;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        gray_out  <= 8'd0;
        out_valid <= 1'b0;
    end
    else begin
        if (in_valid)
            gray_out <= gray_sum[15:8];

        out_valid <= in_valid;
    end
end

endmodule