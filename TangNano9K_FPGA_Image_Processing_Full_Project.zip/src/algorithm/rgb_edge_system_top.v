`timescale 1ns / 1ps

// Whole RGB -> Gray -> Gaussian -> Sobel -> Gradient/Edge stream.
// This is an algorithm/system integration top
// board-level PSRAM/HDMI top. The visible coordinates are the
// original full-frame pixel coordinates.
module rgb_edge_system_top (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [23:0] rgb_in,
    input  wire        in_valid,
    input  wire [9:0]  in_x,
    input  wire [8:0]  in_y,
    input  wire [7:0]  threshold,

    // Expose Gray stream for system-level checking/future frame writing.
    output wire [7:0]  gray_out,
    output wire        gray_valid,
    output wire [9:0]  gray_x,
    output wire [8:0]  gray_y,

    output wire [7:0]  gradient_out,
    output wire [7:0]  edge_out,
    output wire        out_valid,
    output wire [9:0]  out_x,
    output wire [8:0]  out_y,

    output wire        frame_done,
    output wire [31:0] frame_cycles,
    output wire [31:0] accepted_inputs,
    output wire [31:0] produced_outputs,

    output wire [7:0]  gauss_out,
    output wire        gauss_out_valid,
    output wire [9:0]  gauss_out_x,
    output wire [8:0]  gauss_out_y
);
    rgb2gray u_rgb2gray (
        .clk      (clk),
        .rst_n    (rst_n),
        .rgb_r    (rgb_in[23:16]),
        .rgb_g    (rgb_in[15:8]),
        .rgb_b    (rgb_in[7:0]),
        .in_valid (in_valid),
        .gray_out (gray_out),
        .out_valid(gray_valid)
    );

    // IMPORTANT: rgb2gray is registered (one clock). Delay
    // coordinates by the same amount, or the 3x3 windows will
    // be associated with the wrong source pixel.
    reg [9:0] x_d;
    reg [8:0] y_d;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            x_d <= 10'd0;
            y_d <= 9'd0;
        end else if (in_valid) begin
            x_d <= in_x;
            y_d <= in_y;
        end
    end
    assign gray_x = x_d;
    assign gray_y = y_d;

    edge_pipeline_top u_edge (
        .clk         (clk),
        .rst_n       (rst_n),
        .gray_in     (gray_out),
        .in_valid    (gray_valid),
        .in_x        (gray_x),
        .in_y        (gray_y),
        .threshold   (threshold),
        .gauss_out    (gauss_out),
        .gauss_out_valid(gauss_out_valid),
        .gauss_out_x  (gauss_out_x),
        .gauss_out_y  (gauss_out_y),
        .gradient_out(gradient_out),
        .edge_out    (edge_out),
        .out_x       (out_x),
        .out_y       (out_y),
        .out_valid   (out_valid)
    );

    frame_perf_counter #(.IMG_W(640), .IMG_H(480)) u_perf (
        .clk             (clk),
        .rst_n           (rst_n),
        .in_valid        (in_valid),
        .in_x            (in_x),
        .in_y            (in_y),
        .out_valid       (out_valid),
        .out_x           (out_x),
        .out_y           (out_y),
        .frame_done      (frame_done),
        .frame_cycles    (frame_cycles),
        .accepted_inputs (accepted_inputs),
        .produced_outputs(produced_outputs)
    );
endmodule
