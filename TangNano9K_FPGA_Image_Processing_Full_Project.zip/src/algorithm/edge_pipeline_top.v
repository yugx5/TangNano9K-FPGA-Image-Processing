`timescale 1ns / 1ps

module edge_pipeline_top #(
    parameter IMG_W = 640,
    parameter X_W   = 10,
    parameter Y_W   = 9
)(
    input  wire             clk,
    input  wire             rst_n,

    input  wire [7:0]       gray_in,
    input  wire             in_valid,

    input  wire [X_W-1:0]   in_x,
    input  wire [Y_W-1:0]   in_y,

    input  wire [7:0]       threshold,

    output wire [7:0]       gradient_out,
    output wire [7:0]       edge_out,

    output wire [X_W-1:0]   out_x,
    output wire [Y_W-1:0]   out_y,

    output wire             out_valid,

    // Export the already-computed Gaussian stream for framebuffer writing.
    output wire [7:0] gauss_out,
    output wire       gauss_out_valid,
    output wire [9:0] gauss_out_x,
    output wire [8:0] gauss_out_y
);

    // ========================================================
    // Stage 1
    // Gray -> Gaussian
    // ========================================================

    wire [7:0] gaussian_pixel;

    wire [X_W-1:0] gaussian_x;
    wire [Y_W-1:0] gaussian_y;

    wire gaussian_valid;


    gaussian_pipeline_top #(
        .IMG_W (640),
        .X_W   (X_W),
        .Y_W   (Y_W)
    ) u_gaussian_pipeline (
        .clk          (clk),
        .rst_n        (rst_n),

        .gray_in      (gray_in),

        .in_valid     (in_valid),

        .in_x         (in_x),
        .in_y         (in_y),

        .gaussian_out (gaussian_pixel),

        .out_x        (gaussian_x),
        .out_y        (gaussian_y),

        .out_valid    (gaussian_valid)
    );


    // ========================================================
    // Gaussian valid image is 638 x 478:
    //
    // Original coordinates:
    // x = 1..638
    // y = 1..478
    //
    // Convert to compact raster:
    // x = 0..637
    // y = 0..477
    //
    // This allows reuse of the exact same line-buffer/window
    // architecture without storing a full intermediate frame.
    // ========================================================

    wire [X_W-1:0] gx_compact;
    wire [Y_W-1:0] gy_compact;

    assign gx_compact =
        gaussian_x - 10'd1;

    assign gy_compact =
        gaussian_y - 9'd1;


    // ========================================================
    // Stage 2 line buffer
    // Gaussian image width = 638
    // ========================================================

    wire [7:0] sobel_row_m2;
    wire [7:0] sobel_row_m1;
    wire [7:0] sobel_row_cur;

    wire [X_W-1:0] sobel_lb_x;
    wire [Y_W-1:0] sobel_lb_y;

    wire sobel_lb_valid;


    line_buffer_3bank #(
        .IMG_W (638),
        .X_W   (X_W),
        .Y_W   (Y_W)
    ) u_sobel_line_buffer (
        .clk         (clk),
        .rst_n       (rst_n),

        .in_pixel    (gaussian_pixel),

        .in_valid    (gaussian_valid),

        .in_x        (gx_compact),
        .in_y        (gy_compact),

        .out_row_m2  (sobel_row_m2),
        .out_row_m1  (sobel_row_m1),
        .out_row_cur (sobel_row_cur),

        .out_x       (sobel_lb_x),
        .out_y       (sobel_lb_y),

        .out_valid   (sobel_lb_valid)
    );


    // ========================================================
    // Stage 2 3x3 window
    // ========================================================

    wire [7:0] s00;
    wire [7:0] s01;
    wire [7:0] s02;

    wire [7:0] s10;
    wire [7:0] s11;
    wire [7:0] s12;

    wire [7:0] s20;
    wire [7:0] s21;
    wire [7:0] s22;

    wire [X_W-1:0] sobel_center_x_compact;
    wire [Y_W-1:0] sobel_center_y_compact;

    wire sobel_window_valid;


    window3x3 #(
        .X_W (X_W),
        .Y_W (Y_W)
    ) u_sobel_window (
        .clk       (clk),
        .rst_n     (rst_n),

        .row_m2    (sobel_row_m2),
        .row_m1    (sobel_row_m1),
        .row_cur   (sobel_row_cur),

        .in_x      (sobel_lb_x),
        .in_y      (sobel_lb_y),

        .in_valid  (sobel_lb_valid),

        .p00       (s00),
        .p01       (s01),
        .p02       (s02),

        .p10       (s10),
        .p11       (s11),
        .p12       (s12),

        .p20       (s20),
        .p21       (s21),
        .p22       (s22),

        .center_x  (sobel_center_x_compact),
        .center_y  (sobel_center_y_compact),

        .out_valid (sobel_window_valid)
    );


    // ========================================================
    // Convert compact Sobel coordinates back to original frame
    //
    // compact x 1..636 -> original x 2..637
    // compact y 1..476 -> original y 2..477
    // ========================================================

    wire [X_W-1:0] sobel_x_original;
    wire [Y_W-1:0] sobel_y_original;

    assign sobel_x_original =
        sobel_center_x_compact + 10'd1;

    assign sobel_y_original =
        sobel_center_y_compact + 9'd1;


    // ========================================================
    // Sobel arithmetic core
    // ========================================================

    wire [7:0] gradient_internal;

    wire [X_W-1:0] sobel_out_x;
    wire [Y_W-1:0] sobel_out_y;

    wire sobel_valid;


    sobel3x3_opt #(
        .X_W (X_W),
        .Y_W (Y_W)
    ) u_sobel (
        .clk          (clk),
        .rst_n        (rst_n),

        .p00          (s00),
        .p01          (s01),
        .p02          (s02),

        .p10          (s10),
        .p11          (s11),
        .p12          (s12),

        .p20          (s20),
        .p21          (s21),
        .p22          (s22),

        .in_x         (sobel_x_original),
        .in_y         (sobel_y_original),

        .in_valid     (sobel_window_valid),

        .gradient_out (gradient_internal),

        .out_x        (sobel_out_x),
        .out_y        (sobel_out_y),

        .out_valid    (sobel_valid)
    );


    // ========================================================
    // Dynamic threshold
    // ========================================================

    threshold8 u_threshold (
        .gradient_in (gradient_internal),
        .threshold   (threshold),
        .edge_out    (edge_out)
    );


    assign gradient_out =
        gradient_internal;

    assign out_x =
        sobel_out_x;

    assign out_y =
        sobel_out_y;

    assign out_valid =
        sobel_valid;


    // Formal ports for the Gaussian stream.  No algorithm logic is changed.
    assign gauss_out       = gaussian_pixel;
    assign gauss_out_valid = gaussian_valid;
    assign gauss_out_x     = gaussian_x;
    assign gauss_out_y     = gaussian_y;

endmodule