`timescale 1ns / 1ps

// Frame-level hardware cycle/throughput counter.
// Measure from first accepted RGB pixel (0,0) through last
// valid Sobel output (IMG_W-3, IMG_H-3).
// For a continuous input stream, accepted_inputs should be
// IMG_W*IMG_H and produced_outputs should be
// (IMG_W-4)*(IMG_H-4).
module frame_perf_counter #(
    parameter IMG_W = 640,
    parameter IMG_H = 480
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        in_valid,
    input  wire [9:0]  in_x,
    input  wire [8:0]  in_y,
    input  wire        out_valid,
    input  wire [9:0]  out_x,
    input  wire [8:0]  out_y,
    output reg         frame_done,
    output reg [31:0] frame_cycles,
    output reg [31:0] accepted_inputs,
    output reg [31:0] produced_outputs
);
    reg running;
    reg [31:0] cycle_counter;

    wire start_frame = in_valid && (in_x == 0) && (in_y == 0) && !running;
    wire last_output = out_valid &&
                       (out_x == IMG_W-3) && (out_y == IMG_H-3);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            running          <= 1'b0;
            frame_done       <= 1'b0;
            frame_cycles     <= 32'd0;
            cycle_counter    <= 32'd0;
            accepted_inputs  <= 32'd0;
            produced_outputs <= 32'd0;
        end else if (start_frame) begin
            running          <= 1'b1;
            frame_done       <= 1'b0;
            frame_cycles     <= 32'd0;
            cycle_counter    <= 32'd1;
            accepted_inputs  <= 32'd1;
            produced_outputs <= 32'd0;
        end else if (running) begin
            cycle_counter <= cycle_counter + 32'd1;
            if (in_valid)
                accepted_inputs <= accepted_inputs + 32'd1;
            if (out_valid)
                produced_outputs <= produced_outputs + 32'd1;
            if (last_output) begin
                frame_cycles <= cycle_counter + 32'd1;
                running      <= 1'b0;
                frame_done   <= 1'b1;
            end
        end
    end
endmodule
