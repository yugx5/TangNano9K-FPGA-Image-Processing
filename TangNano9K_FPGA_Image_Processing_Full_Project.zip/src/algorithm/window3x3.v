`timescale 1ns / 1ps

// ============================================================
// Streaming 3x3 Window Generator
//
// Input:
// row_m2 = pixel(y-2, x)
// row_m1 = pixel(y-1, x)
// row_cur= pixel(y,   x)
//
// When current input coordinate is (x,y):
//
// p00 p01 p02   = y-2
// p10 p11 p12   = y-1
// p20 p21 p22   = y
//
// Center coordinate:
// center_x = x - 1
// center_y = y - 1
//
// Valid center:
// x = 1...638
// y = 1...478
// ============================================================
module window3x3 #(
    parameter X_W = 10,
    parameter Y_W = 9
)(
    input  wire              clk,
    input  wire              rst_n,

    input  wire [7:0]        row_m2,
    input  wire [7:0]        row_m1,
    input  wire [7:0]        row_cur,

    input  wire [X_W-1:0]    in_x,
    input  wire [Y_W-1:0]    in_y,
    input  wire              in_valid,

    output reg [7:0]         p00,
    output reg [7:0]         p01,
    output reg [7:0]         p02,

    output reg [7:0]         p10,
    output reg [7:0]         p11,
    output reg [7:0]         p12,

    output reg [7:0]         p20,
    output reg [7:0]         p21,
    output reg [7:0]         p22,

    output reg [X_W-1:0]     center_x,
    output reg [Y_W-1:0]     center_y,
    output reg               out_valid
);

    // Previous two horizontal pixels
    reg [7:0] r0_d1;
    reg [7:0] r0_d2;

    reg [7:0] r1_d1;
    reg [7:0] r1_d2;

    reg [7:0] r2_d1;
    reg [7:0] r2_d2;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            r0_d1 <= 8'd0;
            r0_d2 <= 8'd0;

            r1_d1 <= 8'd0;
            r1_d2 <= 8'd0;

            r2_d1 <= 8'd0;
            r2_d2 <= 8'd0;

            p00 <= 8'd0;
            p01 <= 8'd0;
            p02 <= 8'd0;

            p10 <= 8'd0;
            p11 <= 8'd0;
            p12 <= 8'd0;

            p20 <= 8'd0;
            p21 <= 8'd0;
            p22 <= 8'd0;

            center_x <= {X_W{1'b0}};
            center_y <= {Y_W{1'b0}};

            out_valid <= 1'b0;
        end
        else begin
            out_valid <= 1'b0;

            if (in_valid) begin

                // --------------------------------------------
                // First pixel of a new row:
                // clear horizontal history from previous row.
                // --------------------------------------------
                if (in_x == 0) begin
                    r0_d2 <= 8'd0;
                    r0_d1 <= row_m2;

                    r1_d2 <= 8'd0;
                    r1_d1 <= row_m1;

                    r2_d2 <= 8'd0;
                    r2_d1 <= row_cur;
                end

                else begin

                    // ----------------------------------------
                    // Once x>=2 and y>=2 a full 3x3 window
                    // exists.
                    // ----------------------------------------
                    if ((in_x >= 2) && (in_y >= 2)) begin
                        p00 <= r0_d2;
                        p01 <= r0_d1;
                        p02 <= row_m2;

                        p10 <= r1_d2;
                        p11 <= r1_d1;
                        p12 <= row_m1;

                        p20 <= r2_d2;
                        p21 <= r2_d1;
                        p22 <= row_cur;

                        center_x <= in_x - 1'b1;
                        center_y <= in_y - 1'b1;

                        out_valid <= 1'b1;
                    end

                    // Shift horizontally
                    r0_d2 <= r0_d1;
                    r0_d1 <= row_m2;

                    r1_d2 <= r1_d1;
                    r1_d1 <= row_m1;

                    r2_d2 <= r2_d1;
                    r2_d1 <= row_cur;
                end
            end
        end
    end

endmodule