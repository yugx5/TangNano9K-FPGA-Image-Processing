`timescale 1ns / 1ps

// ============================================================
// Single-Port Line RAM
// Target: Gowin BSRAM inference
// ============================================================
module line_ram_sp #(
    parameter DATA_W = 8,
    parameter ADDR_W = 10,
    parameter DEPTH  = 640
)(
    input  wire                  clk,
    input  wire                  en,
    input  wire                  we,
    input  wire [ADDR_W-1:0]     addr,
    input  wire [DATA_W-1:0]     din,
    output reg  [DATA_W-1:0]     dout
);

    // Use the full power-of-two address range so Gowin can infer a native BSRAM.
    localparam integer PHYS_DEPTH = (1 << ADDR_W);
    reg [DATA_W-1:0] mem [0:PHYS_DEPTH-1] /* synthesis syn_ramstyle = "block_ram" */;

    // Do NOT reset the memory array.
    // Resetting the whole array may prevent BSRAM inference.
    always @(posedge clk) begin
        if (en) begin
            if (we) begin
                mem[addr] <= din;
            end
            else begin
                // synchronous read
                dout <= mem[addr];
            end
        end
    end

endmodule


// ============================================================
// 3-Bank Rotating Line Buffer
//
// Bank roles rotate every image row:
//
// row N:
//   two banks = read N-2 / N-1
//   one bank  = write N
//
// No whole-line data movement.
// Only logical bank roles rotate.
//
// Input raster:
// x = 0...639
// y = 0...479
//
// Output:
// out_row_m2 : pixel(y-2, x)
// out_row_m1 : pixel(y-1, x)
// out_row_cur: pixel(y,   x)
//
// Synchronous BSRAM latency is explicitly aligned here.
// ============================================================
module line_buffer_3bank #(
    parameter IMG_W = 640,
    parameter X_W   = 10,
    parameter Y_W   = 9
)(
    input  wire              clk,
    input  wire              rst_n,

    input  wire [7:0]        in_pixel,
    input  wire              in_valid,
    input  wire [X_W-1:0]    in_x,
    input  wire [Y_W-1:0]    in_y,

    output wire [7:0]        out_row_m2,
    output wire [7:0]        out_row_m1,
    output wire [7:0]        out_row_cur,

    output wire [X_W-1:0]    out_x,
    output wire [Y_W-1:0]    out_y,
    output wire              out_valid
);

    // --------------------------------------------------------
    // Bank outputs
    // --------------------------------------------------------
    wire [7:0] q0;
    wire [7:0] q1;
    wire [7:0] q2;

    // Which bank is currently being written
    // 0 -> Bank0
    // 1 -> Bank1
    // 2 -> Bank2
    reg [1:0] write_sel;

    wire we0;
    wire we1;
    wire we2;

    assign we0 = in_valid && (write_sel == 2'd0);
    assign we1 = in_valid && (write_sel == 2'd1);
    assign we2 = in_valid && (write_sel == 2'd2);

    // --------------------------------------------------------
    // Three physically independent RAM banks
    // --------------------------------------------------------
    line_ram_sp #(
        .DATA_W(8),
        .ADDR_W(X_W),
        .DEPTH(IMG_W)
    ) u_bank0 (
        .clk  (clk),
        .en   (in_valid),
        .we   (we0),
        .addr (in_x),
        .din  (in_pixel),
        .dout (q0)
    );

    line_ram_sp #(
        .DATA_W(8),
        .ADDR_W(X_W),
        .DEPTH(IMG_W)
    ) u_bank1 (
        .clk  (clk),
        .en   (in_valid),
        .we   (we1),
        .addr (in_x),
        .din  (in_pixel),
        .dout (q1)
    );

    line_ram_sp #(
        .DATA_W(8),
        .ADDR_W(X_W),
        .DEPTH(IMG_W)
    ) u_bank2 (
        .clk  (clk),
        .en   (in_valid),
        .we   (we2),
        .addr (in_x),
        .din  (in_pixel),
        .dout (q2)
    );

    // --------------------------------------------------------
    // Metadata / current pixel delay
    //
    // BSRAM read is synchronous, so current pixel and
    // coordinates must be delayed to stay aligned.
    // --------------------------------------------------------
    reg [7:0]       cur_d;
    reg [X_W-1:0]   x_d;
    reg [Y_W-1:0]   y_d;
    reg             valid_d;
    reg [1:0]       sel_d;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            write_sel <= 2'd0;

            cur_d     <= 8'd0;
            x_d       <= {X_W{1'b0}};
            y_d       <= {Y_W{1'b0}};
            valid_d   <= 1'b0;
            sel_d     <= 2'd0;
        end
        else begin
            valid_d <= 1'b0;

            if (in_valid) begin
                // Save metadata corresponding to RAM output
                cur_d   <= in_pixel;
                x_d     <= in_x;
                y_d     <= in_y;
                sel_d   <= write_sel;
                valid_d <= 1'b1;

                // Rotate bank roles only at end of row
                if (in_x == IMG_W - 1) begin
                    if (write_sel == 2'd2)
                        write_sel <= 2'd0;
                    else
                        write_sel <= write_sel + 2'd1;
                end
            end
        end
    end

    // --------------------------------------------------------
    // Select which physical banks represent y-2 and y-1
    //
    // write Bank0:
    //   Bank1 = y-2
    //   Bank2 = y-1
    //
    // write Bank1:
    //   Bank2 = y-2
    //   Bank0 = y-1
    //
    // write Bank2:
    //   Bank0 = y-2
    //   Bank1 = y-1
    // --------------------------------------------------------
    reg [7:0] row_m2_mux;
    reg [7:0] row_m1_mux;

    always @(*) begin
        row_m2_mux = 8'd0;
        row_m1_mux = 8'd0;

        case (sel_d)
            2'd0: begin
                row_m2_mux = q1;
                row_m1_mux = q2;
            end

            2'd1: begin
                row_m2_mux = q2;
                row_m1_mux = q0;
            end

            2'd2: begin
                row_m2_mux = q0;
                row_m1_mux = q1;
            end

            default: begin
                row_m2_mux = 8'd0;
                row_m1_mux = 8'd0;
            end
        endcase
    end

    assign out_row_m2  = row_m2_mux;
    assign out_row_m1  = row_m1_mux;
    assign out_row_cur = cur_d;

    assign out_x       = x_d;
    assign out_y       = y_d;
    assign out_valid   = valid_d;

endmodule