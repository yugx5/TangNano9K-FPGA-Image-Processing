`timescale 1ns / 1ps

// ============================================================
// V11: Direction-Balanced Approximate-Magnitude Sobel Kernel
//
// Gx =
//  -1  0  +1
//  -2  0  +2
//  -1  0  +1
//
// Gy =
//  -1 -2  -1
//   0  0   0
//  +1 +2  +1
//
// Gradient11 = max(|Gx|,|Gy|) + min(|Gx|,|Gy|)/2
// Bound: 0 ~ 1530
//
// Gradient8 = Gradient11 >> 3 (same scale as baseline)
// Bound: 0 ~ 191
//
// ============================================================

module sobel3x3_opt #(
    parameter X_W = 10,
    parameter Y_W = 9
)(
    input  wire             clk,
    input  wire             rst_n,

    input  wire [7:0]       p00,
    input  wire [7:0]       p01,
    input  wire [7:0]       p02,

    input  wire [7:0]       p10,
    input  wire [7:0]       p11,
    input  wire [7:0]       p12,

    input  wire [7:0]       p20,
    input  wire [7:0]       p21,
    input  wire [7:0]       p22,

    input  wire [X_W-1:0]   in_x,
    input  wire [Y_W-1:0]   in_y,
    input  wire             in_valid,

    output reg  [7:0]       gradient_out,
    output reg  [X_W-1:0]   out_x,
    output reg  [Y_W-1:0]   out_y,
    output reg              out_valid
);

    // Each positive/negative Sobel half:
    // maximum = 255 + 2*255 + 255 = 1020
    wire [9:0] gx_pos;
    wire [9:0] gx_neg;

    wire [9:0] gy_pos;
    wire [9:0] gy_neg;

    assign gx_pos =
          {2'b00, p02}
        + {1'b0, p12, 1'b0}
        + {2'b00, p22};

    assign gx_neg =
          {2'b00, p00}
        + {1'b0, p10, 1'b0}
        + {2'b00, p20};

    assign gy_pos =
          {2'b00, p20}
        + {1'b0, p21, 1'b0}
        + {2'b00, p22};

    assign gy_neg =
          {2'b00, p00}
        + {1'b0, p01, 1'b0}
        + {2'b00, p02};


    // Signed range: -1020 ~ +1020
    wire signed [10:0] gx_signed;
    wire signed [10:0] gy_signed;

    assign gx_signed =
        $signed({1'b0, gx_pos})
        -
        $signed({1'b0, gx_neg});

    assign gy_signed =
        $signed({1'b0, gy_pos})
        -
        $signed({1'b0, gy_neg});


    // Absolute value
    wire [10:0] gx_bits;
    wire [10:0] gy_bits;

    assign gx_bits = gx_signed;
    assign gy_bits = gy_signed;

    wire [10:0] abs_gx;
    wire [10:0] abs_gy;

    assign abs_gx =
        gx_signed[10]
        ? (~gx_bits + 11'd1)
        : gx_bits;

    assign abs_gy =
        gy_signed[10]
        ? (~gy_bits + 11'd1)
        : gy_bits;


    // V11: direction-balanced approximate Euclidean magnitude.
    //   M = max(|Gx|, |Gy|) + floor(min(|Gx|, |Gy|) / 2)
    //
    // A vertical/horizontal edge with one zero component keeps its
    // original magnitude. Diagonal edges that previously benefited
    // from L1 addition are relatively dimmer.
    //
    // Maximum conservative bound = 1020 + 1020/2 = 1530,
    // so 11 bits are sufficient. Retain original >>3 scaling
    // for controlled comparison, with no new register stage.
    wire [10:0] major_grad =
        (abs_gx >= abs_gy) ? abs_gx : abs_gy;

    wire [10:0] minor_grad =
        (abs_gx >= abs_gy) ? abs_gy : abs_gx;

    wire [10:0] gradient11 =
        major_grad + (minor_grad >> 1);


    // ========================================================
    // Output register
    // ========================================================

    always @(posedge clk or negedge rst_n) begin

        if (!rst_n) begin

            gradient_out <= 8'd0;

            out_x <= {X_W{1'b0}};
            out_y <= {Y_W{1'b0}};

            out_valid <= 1'b0;

        end
        else begin

            out_valid <= in_valid;

            if (in_valid) begin

                // Keep original >>3 scaling and single-cycle output.
                gradient_out <= gradient11[10:3];

                out_x <= in_x;
                out_y <= in_y;

            end
        end
    end

endmodule