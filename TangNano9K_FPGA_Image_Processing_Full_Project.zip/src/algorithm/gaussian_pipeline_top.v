`timescale 1ns / 1ps

// ============================================================
// Gaussian Streaming Pipeline
//
// Gray Stream
//    |
//    v
// 3-Bank BSRAM Line Buffer
//    |
//    v
// 3x3 Window Generator
//    |
//    v
// Optimized Gaussian Core
//
// This module is synthesizable.
// ============================================================

module gaussian_pipeline_top #(
    parameter IMG_W = 640,
    parameter X_W   = 10,
    parameter Y_W   = 9
)(
    input  wire             clk,
    input  wire             rst_n,

    input  wire [7:0]       gray_in,
    input  wire             in_valid,

    input  wire [X_W-1:0]   in_x,
    input  wire [Y_W-1:0]   in_y,

    output wire [7:0]       gaussian_out,
    output wire [X_W-1:0]   out_x,
    output wire [Y_W-1:0]   out_y,
    output wire             out_valid
);

    // ========================================================
    // Line Buffer outputs
    // ========================================================

    wire [7:0] row_m2;
    wire [7:0] row_m1;
    wire [7:0] row_cur;

    wire [X_W-1:0] lb_x;
    wire [Y_W-1:0] lb_y;
    wire           lb_valid;


    line_buffer_3bank #(
        .IMG_W (IMG_W),
        .X_W   (X_W),
        .Y_W   (Y_W)
    ) u_line_buffer (
        .clk         (clk),
        .rst_n       (rst_n),

        .in_pixel    (gray_in),
        .in_valid    (in_valid),

        .in_x        (in_x),
        .in_y        (in_y),

        .out_row_m2  (row_m2),
        .out_row_m1  (row_m1),
        .out_row_cur (row_cur),

        .out_x       (lb_x),
        .out_y       (lb_y),
        .out_valid   (lb_valid)
    );


    // ========================================================
    // 3x3 Window
    // ========================================================

    wire [7:0] p00;
    wire [7:0] p01;
    wire [7:0] p02;

    wire [7:0] p10;
    wire [7:0] p11;
    wire [7:0] p12;

    wire [7:0] p20;
    wire [7:0] p21;
    wire [7:0] p22;

    wire [X_W-1:0] center_x;
    wire [Y_W-1:0] center_y;

    wire win_valid;


    window3x3 #(
        .X_W (X_W),
        .Y_W (Y_W)
    ) u_window (
        .clk       (clk),
        .rst_n     (rst_n),

        .row_m2    (row_m2),
        .row_m1    (row_m1),
        .row_cur   (row_cur),

        .in_x      (lb_x),
        .in_y      (lb_y),

        .in_valid  (lb_valid),

        .p00       (p00),
        .p01       (p01),
        .p02       (p02),

        .p10       (p10),
        .p11       (p11),
        .p12       (p12),

        .p20       (p20),
        .p21       (p21),
        .p22       (p22),

        .center_x  (center_x),
        .center_y  (center_y),

        .out_valid (win_valid)
    );


    // ========================================================
    // Optimized Gaussian Core
    // ========================================================

    gaussian3x3_opt #(
        .X_W (X_W),
        .Y_W (Y_W)
    ) u_gaussian (
        .clk          (clk),
        .rst_n        (rst_n),

        .p00          (p00),
        .p01          (p01),
        .p02          (p02),

        .p10          (p10),
        .p11          (p11),
        .p12          (p12),

        .p20          (p20),
        .p21          (p21),
        .p22          (p22),

        .in_x         (center_x),
        .in_y         (center_y),

        .in_valid     (win_valid),

        .gaussian_out (gaussian_out),

        .out_x        (out_x),
        .out_y        (out_y),

        .out_valid    (out_valid)
    );

endmodule