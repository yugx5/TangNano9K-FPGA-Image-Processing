`timescale 1ns / 1ps

// ============================================================
// V10: Center-Weighted (Edge-Preserving) 3x3 Gaussian Experiment
//
// Kernel:
//       1  2  1
//       2  4  2
//       1  2  1
//       ----------
//            16
//
//
// corners = p00 + p02 + p20 + p22
// edges   = p01 + p10 + p12 + p21
//
// sum = corners + (edges << 1) + (p11 << 2)
//
// Maximum:
// 16 * 255 = 4080
// therefore weighted_sum needs 12 bits.
//
// Output = weighted_sum >> 4
// ============================================================

module gaussian3x3_opt #(
    parameter X_W = 10,
    parameter Y_W = 9
)(
    input  wire             clk,
    input  wire             rst_n,

    input  wire [7:0]       p00,
    input  wire [7:0]       p01,
    input  wire [7:0]       p02,

    input  wire [7:0]       p10,
    input  wire [7:0]       p11,
    input  wire [7:0]       p12,

    input  wire [7:0]       p20,
    input  wire [7:0]       p21,
    input  wire [7:0]       p22,

    input  wire [X_W-1:0]   in_x,
    input  wire [Y_W-1:0]   in_y,
    input  wire             in_valid,

    output reg  [7:0]       gaussian_out,
    output reg  [X_W-1:0]   out_x,
    output reg  [Y_W-1:0]   out_y,
    output reg              out_valid
);

    // Four 8-bit pixels:
    // max = 4 * 255 = 1020
    // 10 bits are sufficient.
    wire [9:0] corner_sum;
    wire [9:0] edge_sum;

    wire [10:0] edge_x2;
    wire [9:0]  center_x4;

    wire [11:0] weighted_sum;


    assign corner_sum =
          {2'b00, p00}
        + {2'b00, p02}
        + {2'b00, p20}
        + {2'b00, p22};


    assign edge_sum =
          {2'b00, p01}
        + {2'b00, p10}
        + {2'b00, p12}
        + {2'b00, p21};


    // Multiply by 2 using shift
    assign edge_x2 =
        {edge_sum, 1'b0};


    // Multiply center pixel by 4
    assign center_x4 =
        {p11, 2'b00};


    // 12-bit exact original weighted sum (unchanged).
    assign weighted_sum =
          {2'b00, corner_sum}
        + {1'b0, edge_x2}
        + {2'b00, center_x4};

    // V10: edge-preserving, half-strength Gaussian filtering:
    //   y = floor((Gaussian_3x3 + center_pixel) / 2)
    //     = floor((weighted_sum + 16*p11) / 32).
    //
    // Equivalent integer kernel /32:
    //       1   2   1
    //       2  20   2
    //       1   2   1
    //
    // Maximum sum = 32*255 = 8160 (13 bits).
    // A single wider adder + shift, no new registers or cycles.
    wire [12:0] edge_preserving_sum =
        {1'b0, weighted_sum} + {1'b0, p11, 4'b0000};


    // --------------------------------------------------------
    // Pipeline output register
    // --------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin

        if (!rst_n) begin

            gaussian_out <= 8'd0;

            out_x         <= {X_W{1'b0}};
            out_y         <= {Y_W{1'b0}};

            out_valid     <= 1'b0;

        end
        else begin

            out_valid <= in_valid;

            if (in_valid) begin

                // V10: weighted sum divided by 32, truncating.
                // Latency and x/y/valid alignment match the original.
                gaussian_out <= edge_preserving_sum[12:5];

                out_x <= in_x;
                out_y <= in_y;

            end
        end
    end

endmodule