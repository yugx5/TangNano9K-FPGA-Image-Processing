`timescale 1ns / 1ps

module threshold8 (
    input  wire [7:0] gradient_in,
    input  wire [7:0] threshold,
    output wire [7:0] edge_out
);

    assign edge_out =
        (gradient_in >= threshold)
        ? 8'hFF
        : 8'h00;

endmodule