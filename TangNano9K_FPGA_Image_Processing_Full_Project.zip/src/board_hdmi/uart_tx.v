module uart_tx #(
    parameter integer CLK_HZ = 54_000_000,
    parameter integer BAUD = 115200
) (
    input clk,
    input resetn,
    input [7:0] data,
    input valid,
    output reg ready,
    output reg tx
);
    localparam integer DIV = CLK_HZ / BAUD;
    reg [15:0] count;
    reg [3:0] bit_index;
    reg [9:0] shift;
    always @(posedge clk) begin
        if (!resetn) begin
            count <= 0; bit_index <= 0; shift <= 10'h3ff; ready <= 1'b1; tx <= 1'b1;
        end else if (ready) begin
            tx <= 1'b1;
            if (valid) begin
                shift <= {1'b1,data,1'b0};
                count <= DIV-1;
                bit_index <= 0;
                ready <= 1'b0;
                tx <= 1'b0;
            end
        end else if (count == 0) begin
            if (bit_index == 9) begin ready <= 1'b1; tx <= 1'b1; end
            else begin
                bit_index <= bit_index + 1'b1;
                shift <= {1'b1,shift[9:1]};
                tx <= shift[1];
                count <= DIV-1;
            end
        end else count <= count - 1'b1;
    end
endmodule
