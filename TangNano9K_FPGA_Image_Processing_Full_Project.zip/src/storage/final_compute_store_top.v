`timescale 1ns / 1ps

// ================================================================
//compute_store_top
//
// Board-independent "compute + result frame store" block.
// ================================================================
module final_compute_store_top
(
    input  wire        clk,
    input  wire        rst_n,

    input  wire [23:0] rgb_in,
    input  wire        in_valid,
    input  wire [9:0]  in_x,
    input  wire [8:0]  in_y,
    input  wire [7:0]  threshold,

    output wire        source_pause,
    output wire        clear_done,
    output wire        store_done,

    output wire        mem_wr_req,
    output wire [23:0] mem_wr_addr,
    output wire [7:0]  mem_wr_data,
    input  wire        mem_wr_ready,

    output wire [31:0] clear_write_count,
    output wire [31:0] gray_write_count,
    output wire [31:0] gauss_write_count,
    output wire [31:0] edge_write_count,

    output wire [7:0]  max_gray_fifo,
    output wire [7:0]  max_gauss_fifo,
    output wire [7:0]  max_edge_fifo,
    output wire        fifo_overflow,

    // Debug stream taps used by Stage-3 scoreboard.
    output wire [7:0]  dbg_gray,
    output wire        dbg_gray_valid,
    output wire [9:0]  dbg_gray_x,
    output wire [8:0]  dbg_gray_y,

    output wire [7:0]  dbg_gauss,
    output wire        dbg_gauss_valid,
    output wire [9:0]  dbg_gauss_x,
    output wire [8:0]  dbg_gauss_y,

    output wire [7:0]  dbg_edge,
    output wire        dbg_edge_valid,
    output wire [9:0]  dbg_edge_x,
    output wire [8:0]  dbg_edge_y
);

    wire algo_in_valid;

    wire [7:0] gradient_out;
    wire       frame_done;

    assign algo_in_valid = in_valid && !source_pause;

    rgb_edge_system_top u_algorithm
    (
        .clk              (clk),
        .rst_n            (rst_n),

        .rgb_in           (rgb_in),
        .in_valid         (algo_in_valid),
        .in_x             (in_x),
        .in_y             (in_y),

        .threshold        (threshold),

        .gray_out         (dbg_gray),
        .gray_valid       (dbg_gray_valid),
        .gray_x           (dbg_gray_x),
        .gray_y           (dbg_gray_y),

        .gauss_out        (dbg_gauss),
        .gauss_out_valid  (dbg_gauss_valid),
        .gauss_out_x      (dbg_gauss_x),
        .gauss_out_y      (dbg_gauss_y),

        .gradient_out     (gradient_out),
        .edge_out         (dbg_edge),
        .out_valid        (dbg_edge_valid),
        .out_x            (dbg_edge_x),
        .out_y            (dbg_edge_y),

        .frame_done       (frame_done),
        .frame_cycles     (),
        .accepted_inputs  (),
        .produced_outputs ()
    );

    final_result_store_writer
    #(
        .FIFO_DEPTH (128),
        .FIFO_AW (7),
        .FIFO_AF_LEVEL (80)
    )
    u_writer
    (
        .clk (clk),
        .rst_n (rst_n),

        .gray_valid (dbg_gray_valid),
        .gray_pixel (dbg_gray),
        .gray_x (dbg_gray_x),
        .gray_y (dbg_gray_y),

        .gauss_valid (dbg_gauss_valid),
        .gauss_pixel (dbg_gauss),
        .gauss_x (dbg_gauss_x),
        .gauss_y (dbg_gauss_y),

        .edge_valid (dbg_edge_valid),
        .edge_pixel (gradient_out), // Store raw Sobel gradient; display cache performs max-pooling.
        .edge_x (dbg_edge_x),
        .edge_y (dbg_edge_y),

        .algorithm_frame_done (frame_done),

        .source_pause (source_pause),
        .clear_done (clear_done),
        .store_done (store_done),

        .mem_wr_req (mem_wr_req),
        .mem_wr_addr (mem_wr_addr),
        .mem_wr_data (mem_wr_data),
        .mem_wr_ready (mem_wr_ready),

        .clear_write_count (clear_write_count),
        .gray_write_count (gray_write_count),
        .gauss_write_count (gauss_write_count),
        .edge_write_count (edge_write_count),

        .max_gray_fifo (max_gray_fifo),
        .max_gauss_fifo (max_gauss_fifo),
        .max_edge_fifo (max_edge_fifo),

        .fifo_overflow (fifo_overflow)
    );

endmodule
