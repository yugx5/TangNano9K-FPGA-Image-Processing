`timescale 1ns / 1ps

// FIFO pixel entry layout:
// { y[8:0], x[9:0], pixel[7:0] } = 27 bits.
module pixel_stream_fifo
#(
    parameter DEPTH = 128,
    parameter AW = 7,
    parameter ALMOST_FULL_LEVEL = 80
)
(
    input  wire        clk,
    input  wire        rst_n,

    input  wire        push,
    input  wire [7:0]  in_pixel,
    input  wire [9:0]  in_x,
    input  wire [8:0]  in_y,

    input  wire        pop,

    output wire [7:0]  out_pixel,
    output wire [9:0]  out_x,
    output wire [8:0]  out_y,

    output wire        full,
    output wire        empty,
    output wire        almost_full,
    output reg  [AW:0] count,
    output reg         overflow
);

    reg [26:0] mem [0:DEPTH-1];
    reg [AW-1:0] wr_ptr;
    reg [AW-1:0] rd_ptr;

    wire do_push;
    wire do_pop;
    wire [26:0] front;

    assign full        = (count == DEPTH);
    assign empty       = (count == 0);
    assign almost_full = (count >= ALMOST_FULL_LEVEL);

    assign do_push = push && !full;
    assign do_pop  = pop  && !empty;

    assign front = mem[rd_ptr];

    assign out_y     = front[26:18];
    assign out_x     = front[17:8];
    assign out_pixel = front[7:0];

    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
        begin
            wr_ptr   <= {AW{1'b0}};
            rd_ptr   <= {AW{1'b0}};
            count    <= {(AW+1){1'b0}};
            overflow <= 1'b0;
        end
        else
        begin
            if (push && full)
                overflow <= 1'b1;

            if (do_push)
            begin
                mem[wr_ptr] <= {in_y, in_x, in_pixel};
                wr_ptr <= wr_ptr + 1'b1;
            end

            if (do_pop)
                rd_ptr <= rd_ptr + 1'b1;

            case ({do_push, do_pop})
                2'b10: count <= count + 1'b1;
                2'b01: count <= count - 1'b1;
                default: count <= count;
            endcase
        end
    end

endmodule
