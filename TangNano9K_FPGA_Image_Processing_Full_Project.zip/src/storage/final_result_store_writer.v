`timescale 1ns / 1ps

// ================================================================
// final_result_store_writer
//
// Framebuffer result writer.
//
// 1. Clears Gray/Gaussian/Edge 640x480 result frames to zero.
// 2. Buffers the three algorithm result streams independently.
// 3. Serializes them onto one generic 8-bit write port.
// 4. Applies source_pause before any FIFO can overflow.
// 5. Declares store_done only after algorithm frame_done has been
//    observed AND all result FIFOs have drained.
//
// Byte-address map:
//   Gray     0x100000
//   Gaussian 0x200000
//   Edge     0x300000
// ================================================================
module final_result_store_writer
#(
    parameter FIFO_DEPTH = 128,
    parameter FIFO_AW = 7,
    parameter FIFO_AF_LEVEL = 80
)
(
    input  wire        clk,
    input  wire        rst_n,

    input  wire        gray_valid,
    input  wire [7:0]  gray_pixel,
    input  wire [9:0]  gray_x,
    input  wire [8:0]  gray_y,

    input  wire        gauss_valid,
    input  wire [7:0]  gauss_pixel,
    input  wire [9:0]  gauss_x,
    input  wire [8:0]  gauss_y,

    input  wire        edge_valid,
    input  wire [7:0]  edge_pixel,
    input  wire [9:0]  edge_x,
    input  wire [8:0]  edge_y,

    input  wire        algorithm_frame_done,

    output wire        source_pause,
    output reg         clear_done,
    output reg         store_done,

    output reg         mem_wr_req,
    output reg  [23:0] mem_wr_addr,
    output reg  [7:0]  mem_wr_data,
    input  wire        mem_wr_ready,

    output reg  [31:0] clear_write_count,
    output reg  [31:0] gray_write_count,
    output reg  [31:0] gauss_write_count,
    output reg  [31:0] edge_write_count,

    output reg  [7:0]  max_gray_fifo,
    output reg  [7:0]  max_gauss_fifo,
    output reg  [7:0]  max_edge_fifo,

    output wire        fifo_overflow
);

    localparam [18:0] FRAME_LAST = 19'd307199;

    wire [23:0] rgb_base;
    wire [23:0] gray_base;
    wire [23:0] gauss_base;
    wire [23:0] edge_base;
    wire [23:0] gradient_base;
    wire [18:0] frame_pixels;

    frame_address_map u_frame_address_map
    (
        .rgb_base      (rgb_base),
        .gray_base     (gray_base),
        .gauss_base    (gauss_base),
        .edge_base     (edge_base),
        .gradient_base (gradient_base),
        .frame_pixels  (frame_pixels)
    );

    // ------------------------------------------------------------
    // Result FIFOs
    // ------------------------------------------------------------
    wire [7:0] gray_fifo_pixel;
    wire [9:0] gray_fifo_x;
    wire [8:0] gray_fifo_y;
    wire       gray_fifo_full;
    wire       gray_fifo_empty;
    wire       gray_fifo_af;
    wire [FIFO_AW:0] gray_fifo_count;
    wire       gray_fifo_overflow;
    reg        gray_fifo_pop;

    wire [7:0] gauss_fifo_pixel;
    wire [9:0] gauss_fifo_x;
    wire [8:0] gauss_fifo_y;
    wire       gauss_fifo_full;
    wire       gauss_fifo_empty;
    wire       gauss_fifo_af;
    wire [FIFO_AW:0] gauss_fifo_count;
    wire       gauss_fifo_overflow;
    reg        gauss_fifo_pop;

    wire [7:0] edge_fifo_pixel;
    wire [9:0] edge_fifo_x;
    wire [8:0] edge_fifo_y;
    wire       edge_fifo_full;
    wire       edge_fifo_empty;
    wire       edge_fifo_af;
    wire [FIFO_AW:0] edge_fifo_count;
    wire       edge_fifo_overflow;
    reg        edge_fifo_pop;

    pixel_stream_fifo
    #(
        .DEPTH (FIFO_DEPTH),
        .AW (FIFO_AW),
        .ALMOST_FULL_LEVEL (FIFO_AF_LEVEL)
    )
    u_gray_fifo
    (
        .clk (clk),
        .rst_n (rst_n),
        .push (gray_valid),
        .in_pixel (gray_pixel),
        .in_x (gray_x),
        .in_y (gray_y),
        .pop (gray_fifo_pop),
        .out_pixel (gray_fifo_pixel),
        .out_x (gray_fifo_x),
        .out_y (gray_fifo_y),
        .full (gray_fifo_full),
        .empty (gray_fifo_empty),
        .almost_full (gray_fifo_af),
        .count (gray_fifo_count),
        .overflow (gray_fifo_overflow)
    );

    pixel_stream_fifo
    #(
        .DEPTH (FIFO_DEPTH),
        .AW (FIFO_AW),
        .ALMOST_FULL_LEVEL (FIFO_AF_LEVEL)
    )
    u_gauss_fifo
    (
        .clk (clk),
        .rst_n (rst_n),
        .push (gauss_valid),
        .in_pixel (gauss_pixel),
        .in_x (gauss_x),
        .in_y (gauss_y),
        .pop (gauss_fifo_pop),
        .out_pixel (gauss_fifo_pixel),
        .out_x (gauss_fifo_x),
        .out_y (gauss_fifo_y),
        .full (gauss_fifo_full),
        .empty (gauss_fifo_empty),
        .almost_full (gauss_fifo_af),
        .count (gauss_fifo_count),
        .overflow (gauss_fifo_overflow)
    );

    pixel_stream_fifo
    #(
        .DEPTH (FIFO_DEPTH),
        .AW (FIFO_AW),
        .ALMOST_FULL_LEVEL (FIFO_AF_LEVEL)
    )
    u_edge_fifo
    (
        .clk (clk),
        .rst_n (rst_n),
        .push (edge_valid),
        .in_pixel (edge_pixel),
        .in_x (edge_x),
        .in_y (edge_y),
        .pop (edge_fifo_pop),
        .out_pixel (edge_fifo_pixel),
        .out_x (edge_fifo_x),
        .out_y (edge_fifo_y),
        .full (edge_fifo_full),
        .empty (edge_fifo_empty),
        .almost_full (edge_fifo_af),
        .count (edge_fifo_count),
        .overflow (edge_fifo_overflow)
    );

    assign fifo_overflow =
        gray_fifo_overflow |
        gauss_fifo_overflow |
        edge_fifo_overflow;

    // Pause the upstream source while clearing or whenever any FIFO
    // approaches capacity.
    assign source_pause =
        !clear_done |
        gray_fifo_af |
        gauss_fifo_af |
        edge_fifo_af;

    // ------------------------------------------------------------
    // Clear state
    // ------------------------------------------------------------
    reg [1:0]  clear_frame;
    reg [18:0] clear_index;

    // ------------------------------------------------------------
    // Stream arbiter
    // ------------------------------------------------------------
    reg [1:0] rr_ptr;
    reg [1:0] selected_stream;
    reg       stream_available;

    reg [18:0] selected_pixel_index;
    reg [23:0] selected_addr;
    reg [7:0]  selected_data;

    reg algorithm_frame_done_seen;

    function [18:0] xy_to_index;
        input [9:0] x;
        input [8:0] y;
        reg [18:0] y640;
        begin
            y640 = ({10'd0, y} << 9) + ({10'd0, y} << 7);
            xy_to_index = y640 + {9'd0, x};
        end
    endfunction

    // Select next non-empty FIFO, starting from rr_ptr.
    always @*
    begin
        selected_stream = 2'd0;
        stream_available = 1'b0;

        case (rr_ptr)
            2'd0:
            begin
                if (!gray_fifo_empty)
                begin
                    selected_stream = 2'd0;
                    stream_available = 1'b1;
                end
                else if (!gauss_fifo_empty)
                begin
                    selected_stream = 2'd1;
                    stream_available = 1'b1;
                end
                else if (!edge_fifo_empty)
                begin
                    selected_stream = 2'd2;
                    stream_available = 1'b1;
                end
            end

            2'd1:
            begin
                if (!gauss_fifo_empty)
                begin
                    selected_stream = 2'd1;
                    stream_available = 1'b1;
                end
                else if (!edge_fifo_empty)
                begin
                    selected_stream = 2'd2;
                    stream_available = 1'b1;
                end
                else if (!gray_fifo_empty)
                begin
                    selected_stream = 2'd0;
                    stream_available = 1'b1;
                end
            end

            default:
            begin
                if (!edge_fifo_empty)
                begin
                    selected_stream = 2'd2;
                    stream_available = 1'b1;
                end
                else if (!gray_fifo_empty)
                begin
                    selected_stream = 2'd0;
                    stream_available = 1'b1;
                end
                else if (!gauss_fifo_empty)
                begin
                    selected_stream = 2'd1;
                    stream_available = 1'b1;
                end
            end
        endcase

        selected_pixel_index = 19'd0;
        selected_addr = 24'd0;
        selected_data = 8'd0;

        case (selected_stream)
            2'd0:
            begin
                selected_pixel_index = xy_to_index(gray_fifo_x, gray_fifo_y);
                selected_addr = gray_base + {5'd0, selected_pixel_index};
                selected_data = gray_fifo_pixel;
            end

            2'd1:
            begin
                selected_pixel_index = xy_to_index(gauss_fifo_x, gauss_fifo_y);
                selected_addr = gauss_base + {5'd0, selected_pixel_index};
                selected_data = gauss_fifo_pixel;
            end

            default:
            begin
                selected_pixel_index = xy_to_index(edge_fifo_x, edge_fifo_y);
                selected_addr = edge_base + {5'd0, selected_pixel_index};
                selected_data = edge_fifo_pixel;
            end
        endcase
    end

    // Memory bus and FIFO pops.
    always @*
    begin
        mem_wr_req  = 1'b0;
        mem_wr_addr = 24'd0;
        mem_wr_data = 8'd0;

        gray_fifo_pop  = 1'b0;
        gauss_fifo_pop = 1'b0;
        edge_fifo_pop  = 1'b0;

        if (!clear_done)
        begin
            mem_wr_req  = 1'b1;
            mem_wr_data = 8'h00;

            case (clear_frame)
                2'd0: mem_wr_addr = gray_base  + {5'd0, clear_index};
                2'd1: mem_wr_addr = gauss_base + {5'd0, clear_index};
                default: mem_wr_addr = edge_base + {5'd0, clear_index};
            endcase
        end
        else if (!store_done && stream_available)
        begin
            mem_wr_req  = 1'b1;
            mem_wr_addr = selected_addr;
            mem_wr_data = selected_data;

            if (mem_wr_ready)
            begin
                case (selected_stream)
                    2'd0: gray_fifo_pop  = 1'b1;
                    2'd1: gauss_fifo_pop = 1'b1;
                    default: edge_fifo_pop = 1'b1;
                endcase
            end
        end
    end

    always @(posedge clk or negedge rst_n)
    begin
        if (!rst_n)
        begin
            clear_frame <= 2'd0;
            clear_index <= 19'd0;
            clear_done  <= 1'b0;
            store_done  <= 1'b0;

            rr_ptr <= 2'd0;
            algorithm_frame_done_seen <= 1'b0;

            clear_write_count <= 32'd0;
            gray_write_count  <= 32'd0;
            gauss_write_count <= 32'd0;
            edge_write_count  <= 32'd0;

            max_gray_fifo  <= 8'd0;
            max_gauss_fifo <= 8'd0;
            max_edge_fifo  <= 8'd0;
        end
        else
        begin
            if (gray_fifo_count > max_gray_fifo)
                max_gray_fifo <= gray_fifo_count[7:0];

            if (gauss_fifo_count > max_gauss_fifo)
                max_gauss_fifo <= gauss_fifo_count[7:0];

            if (edge_fifo_count > max_edge_fifo)
                max_edge_fifo <= edge_fifo_count[7:0];

            if (algorithm_frame_done)
                algorithm_frame_done_seen <= 1'b1;

            if (!clear_done)
            begin
                if (mem_wr_req && mem_wr_ready)
                begin
                    clear_write_count <= clear_write_count + 1'b1;

                    if (clear_index == FRAME_LAST)
                    begin
                        clear_index <= 19'd0;

                        if (clear_frame == 2'd2)
                        begin
                            clear_done <= 1'b1;
                            clear_frame <= 2'd2;
                        end
                        else
                        begin
                            clear_frame <= clear_frame + 1'b1;
                        end
                    end
                    else
                    begin
                        clear_index <= clear_index + 1'b1;
                    end
                end
            end
            else if (!store_done)
            begin
                if (mem_wr_req && mem_wr_ready && stream_available)
                begin
                    case (selected_stream)
                        2'd0:
                        begin
                            gray_write_count <= gray_write_count + 1'b1;
                            rr_ptr <= 2'd1;
                        end

                        2'd1:
                        begin
                            gauss_write_count <= gauss_write_count + 1'b1;
                            rr_ptr <= 2'd2;
                        end

                        default:
                        begin
                            edge_write_count <= edge_write_count + 1'b1;
                            rr_ptr <= 2'd0;
                        end
                    endcase
                end

                if (algorithm_frame_done_seen &&
                    gray_fifo_empty &&
                    gauss_fifo_empty &&
                    edge_fifo_empty &&
                    !gray_valid &&
                    !gauss_valid &&
                    !edge_valid)
                begin
                    store_done <= 1'b1;
                end
            end
        end
    end

endmodule
