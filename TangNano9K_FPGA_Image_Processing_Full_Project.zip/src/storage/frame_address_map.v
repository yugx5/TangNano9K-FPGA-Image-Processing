`timescale 1ns / 1ps

// Framebuffer byte address map.
module frame_address_map
(
    output wire [23:0] rgb_base,
    output wire [23:0] gray_base,
    output wire [23:0] gauss_base,
    output wire [23:0] edge_base,
    output wire [23:0] gradient_base,
    output wire [18:0] frame_pixels
);

    assign rgb_base      = 24'h000000;
    assign gray_base     = 24'h100000;
    assign gauss_base    = 24'h200000;
    assign edge_base     = 24'h300000;
    assign gradient_base = 24'h400000; // reserved

    assign frame_pixels  = 19'd307200;

endmodule
