
module psram_controller #(
    parameter integer FREQ = 54_000_000,
    parameter integer LATENCY = 3
) (
    input             clk,
    input             clk_p,
    input             resetn,
    input             read,
    input             write,
    input      [21:0] addr,
    input      [15:0] din,
    output reg [15:0] dout,
    output            busy,
    output     [1:0]  O_psram_ck,
    inout      [1:0]  IO_psram_rwds,
    inout      [15:0] IO_psram_dq,
    output     [1:0]  O_psram_cs_n
);
    localparam [2:0] INIT_ST=0, CONFIG_ST=1, IDLE_ST=2, READ_ST=3, WRITE_ST=4;
    localparam [3:0] CR_LATENCY = LATENCY == 3 ? 4'b1110 :
                                  LATENCY == 4 ? 4'b1111 :
                                  LATENCY == 5 ? 4'b0000 : 4'b0001;
    localparam integer INIT_TIME = FREQ / 1000 * 160 / 1000;

    reg [2:0] state;
    reg cfg_now, dq_oen, ram_cs_n, ck_e, ck_e_p;
    reg wait_for_rd_data;
    reg [15:0] w_din;
    reg [23:0] cycles_sr;
    reg [63:0] dq_sr;
    reg rwds_out_ris, rwds_out_fal, rwds_oen;
    reg additional_latency;
    reg [$clog2(INIT_TIME+1)-1:0] rst_cnt;
    reg rst_done, rst_done_p1;

    wire [7:0] dq_out_ris = dq_sr[63:56];
    wire [7:0] dq_out_fal = dq_sr[55:48];
    wire [7:0] dq_in_ris;
    wire [7:0] dq_in_fal;
    wire rwds_in_ris, rwds_in_fal;
    wire cs_n_tbuf, cs_n_unused, rwds_tbuf, rwds_oen_tbuf, ck_tbuf, ck_unused;
    wire [7:0] dq_out_tbuf;
    wire [7:0] dq_oen_tbuf;

    assign busy = (state != IDLE_ST);
    assign O_psram_cs_n[0] = cs_n_tbuf;
    assign O_psram_cs_n[1] = 1'b1;
    assign O_psram_ck[0] = ck_tbuf;
    assign O_psram_ck[1] = 1'b0;
    assign IO_psram_rwds[0] = rwds_oen_tbuf ? 1'bz : rwds_tbuf;
    assign IO_psram_rwds[1] = 1'bz;
    assign IO_psram_dq[15:8] = 8'hzz;

    always @(posedge clk) begin
        cycles_sr <= {cycles_sr[22:0], 1'b0};
        dq_sr <= {dq_sr[47:0], 16'b0};
        ck_e_p <= ck_e;

        case (state)
            INIT_ST: if (cfg_now) begin
                cycles_sr <= 24'b1;
                ram_cs_n <= 1'b0;
                state <= CONFIG_ST;
            end
            CONFIG_ST: begin
                if (cycles_sr[0]) begin
                    // Write configuration register 0: variable latency, selected tACC.
                    dq_sr <= {8'h60,8'h00,8'h01,8'h00,8'h00,8'h00,8'h8f,CR_LATENCY,4'h7};
                    dq_oen <= 1'b0;
                    ck_e <= 1'b1;
                end
                if (cycles_sr[4]) begin
                    state <= IDLE_ST;
                    ck_e <= 1'b0;
                    cycles_sr <= 24'b1;
                    dq_oen <= 1'b1;
                    ram_cs_n <= 1'b1;
                end
            end
            IDLE_ST: begin
                rwds_oen <= 1'b1;
                ck_e <= 1'b0;
                ram_cs_n <= 1'b1;
                if (read || write) begin
                    dq_sr <= {~write,13'b010_0000_0000_00,addr[21:4],13'b0,addr[3:1],16'b0000_0100_1101_0100};
                    ram_cs_n <= 1'b0;
                    ck_e <= 1'b1;
                    dq_oen <= 1'b0;
                    wait_for_rd_data <= 1'b0;
                    w_din <= din;
                    cycles_sr <= 24'b10;
                    state <= write ? WRITE_ST : READ_ST;
                end
            end
            READ_ST: begin
                if (cycles_sr[3]) dq_oen <= 1'b1;
                if (cycles_sr[9]) wait_for_rd_data <= 1'b1;
                if (wait_for_rd_data && (rwds_in_ris ^ rwds_in_fal)) begin
                    dout <= {dq_in_ris, dq_in_fal};
                    ram_cs_n <= 1'b1;
                    ck_e <= 1'b0;
                    state <= IDLE_ST;
                end
            end
            WRITE_ST: begin
                if (cycles_sr[5]) additional_latency <= rwds_in_fal;
                if ((cycles_sr[2+LATENCY] && (LATENCY == 3 ? ~rwds_in_fal : ~additional_latency)) ||
                    cycles_sr[2+LATENCY*2]) begin
                    rwds_oen <= 1'b0;
                    rwds_out_ris <= 1'b0;
                    rwds_out_fal <= 1'b0;
                    dq_sr[63:48] <= w_din;
                    state <= IDLE_ST;
                end
            end
            default: state <= INIT_ST;
        endcase

        if (!resetn) begin
            state <= INIT_ST;
            cycles_sr <= 24'b0;
            dq_sr <= 64'b0;
            ram_cs_n <= 1'b1;
            ck_e <= 1'b0;
            ck_e_p <= 1'b0;
            dq_oen <= 1'b1;
            rwds_oen <= 1'b1;
            wait_for_rd_data <= 1'b0;
            additional_latency <= 1'b0;
            dout <= 16'b0;
        end
    end

    always @(posedge clk) begin
        rst_done_p1 <= rst_done;
        cfg_now <= rst_done & ~rst_done_p1;
        if (!resetn) begin
            rst_cnt <= 0;
            rst_done <= 1'b0;
            rst_done_p1 <= 1'b0;
            cfg_now <= 1'b0;
        end else if (!rst_done) begin
            if (rst_cnt == INIT_TIME-1) rst_done <= 1'b1;
            else rst_cnt <= rst_cnt + 1'b1;
        end
    end

    ODDR oddr_cs_n(.CLK(clk), .D0(ram_cs_n), .D1(ram_cs_n), .TX(1'b0),
                   .Q0(cs_n_tbuf), .Q1(cs_n_unused));
    ODDR oddr_rwds(.CLK(clk), .D0(rwds_out_ris), .D1(rwds_out_fal),
                   .TX(rwds_oen), .Q0(rwds_tbuf), .Q1(rwds_oen_tbuf));
    ODDR oddr_ck(.CLK(clk_p), .D0(ck_e_p), .D1(1'b0), .TX(1'b0),
                 .Q0(ck_tbuf), .Q1(ck_unused));
    IDDR iddr_rwds(.CLK(clk), .D(IO_psram_rwds[0]), .Q0(rwds_in_ris), .Q1(rwds_in_fal));

    genvar i;
    generate for (i=0; i<8; i=i+1) begin: psram_dq_io
        ODDR oddr_dq(.CLK(clk), .D0(dq_out_ris[i]), .D1(dq_out_fal[i]),
                     .TX(dq_oen), .Q0(dq_out_tbuf[i]), .Q1(dq_oen_tbuf[i]));
        assign IO_psram_dq[i] = dq_oen_tbuf[i] ? 1'bz : dq_out_tbuf[i];
        IDDR iddr_dq(.CLK(clk), .D(IO_psram_dq[i]), .Q0(dq_in_ris[i]), .Q1(dq_in_fal[i]));
    end endgenerate
endmodule
