// 27 MHz -> 54 MHz, plus a 90-degree phase-shifted PSRAM clock.
module Gowin_rPLL_PSRAM (
    output clkout,
    output clkoutp,
    output lock,
    input  clkin
);
    wire clkoutd_o;
    wire clkoutd3_o;
    wire gw_vcc = 1'b1;
    wire gw_gnd = 1'b0;

    rPLL rpll_inst (
        .CLKOUT(clkout), .LOCK(lock), .CLKOUTP(clkoutp),
        .CLKOUTD(clkoutd_o), .CLKOUTD3(clkoutd3_o),
        .RESET(gw_gnd), .RESET_P(gw_gnd), .CLKIN(clkin), .CLKFB(gw_gnd),
        .FBDSEL(6'b0), .IDSEL(6'b0), .ODSEL(6'b0),
        .PSDA(4'b0), .DUTYDA(4'b0), .FDLY({4{gw_vcc}})
    );
    defparam rpll_inst.FCLKIN = "27";
    defparam rpll_inst.DYN_IDIV_SEL = "false";
    defparam rpll_inst.FBDIV_SEL = 1;
    defparam rpll_inst.IDIV_SEL = 0;
    defparam rpll_inst.ODIV_SEL = 8;
    defparam rpll_inst.DYN_FBDIV_SEL = "false";
    defparam rpll_inst.DYN_ODIV_SEL = "false";
    defparam rpll_inst.PSDA_SEL = "0100";
    defparam rpll_inst.DYN_DA_EN = "false";
    defparam rpll_inst.DUTYDA_SEL = "1000";
    defparam rpll_inst.CLKOUT_FT_DIR = 1'b1;
    defparam rpll_inst.CLKOUTP_FT_DIR = 1'b1;
    defparam rpll_inst.CLKOUT_DLY_STEP = 0;
    defparam rpll_inst.CLKOUTP_DLY_STEP = 0;
    defparam rpll_inst.CLKFB_SEL = "internal";
    defparam rpll_inst.CLKOUT_BYPASS = "false";
    defparam rpll_inst.CLKOUTP_BYPASS = "false";
    defparam rpll_inst.CLKOUTD_BYPASS = "false";
    defparam rpll_inst.DYN_SDIV_SEL = 2;
    defparam rpll_inst.CLKOUTD_SRC = "CLKOUT";
    defparam rpll_inst.CLKOUTD3_SRC = "CLKOUT";
    defparam rpll_inst.DEVICE = "GW1NR-9C";
endmodule
