`timescale 1ns / 1ps
// Stage B: read the complete original RGB565 frame BACK FROM PSRAM before
// sending any pixels into RGB->Gray->Gaussian->Sobel. Holds each pixel under
// existing writer's FIFO almost-full backpressure. No extra line/frame RAM.
module final_psram_rgb_algorithm_source (
    input wire clk,
    input wire rst_n,
    input wire original_done,
    input wire pause,
    output wire rd_req,
    output wire [23:0] rd_addr,
    input wire rd_req_ready,
    input wire rd_valid,
    input wire [7:0] rd_data,
    output wire [23:0] rgb,
    output wire valid,
    output reg [9:0] x,
    output reg [8:0] y,
    output reg frame_done
);
    localparam [2:0] WAIT_FRAME=3'd0, REQUEST_LO=3'd1,
                     WAIT_LO=3'd2, REQUEST_HI=3'd3,
                     WAIT_HI=3'd4, HAVE_PIXEL=3'd5, FINISHED=3'd6;
    reg [2:0] state;
    reg [15:0] rgb565;
    reg [7:0] low_byte;
    wire [18:0] index = (({10'd0,y} << 9) +
                         ({10'd0,y} << 7)) + {9'd0,x};
    wire [23:0] addr_first = {4'd0,index,1'b0};
    assign rd_req = state == REQUEST_LO || state == REQUEST_HI;
    assign rd_addr = addr_first + ((state == REQUEST_HI) ? 24'd1 : 24'd0);
    wire [4:0] r5 = rgb565[15:11];
    wire [5:0] g6 = rgb565[10:5];
    wire [4:0] b5 = rgb565[4:0];
    assign rgb = {{r5,r5[4:2]}, {g6,g6[5:4]}, {b5,b5[4:2]}};
    assign valid = state == HAVE_PIXEL && !pause;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= WAIT_FRAME;
            x <= 10'd0;
            y <= 9'd0;
            rgb565 <= 16'd0;
            low_byte <= 8'd0;
            frame_done <= 1'b0;
        end else begin
            case (state)
                WAIT_FRAME: if (original_done) state <= REQUEST_LO;
                REQUEST_LO: if (rd_req_ready) state <= WAIT_LO;
                WAIT_LO: if (rd_valid) begin
                    low_byte <= rd_data;
                    state <= REQUEST_HI;
                end
                REQUEST_HI: if (rd_req_ready) state <= WAIT_HI;
                WAIT_HI: if (rd_valid) begin
                    rgb565 <= {rd_data,low_byte};
                    state <= HAVE_PIXEL;
                end
                HAVE_PIXEL: if (valid) begin
                    if (x == 10'd639) begin
                        x <= 10'd0;
                        if (y == 9'd479) begin
                            frame_done <= 1'b1;
                            state <= FINISHED;
                        end else begin
                            y <= y + 1'b1;
                            state <= REQUEST_LO;
                        end
                    end else begin
                        x <= x + 1'b1;
                        state <= REQUEST_LO;
                    end
                end
                FINISHED: state <= FINISHED;
                default: state <= WAIT_FRAME;
            endcase
        end
    end
endmodule
