`timescale 1ns / 1ps

// ============================================================
// final_psram_cache_fill
//
// Build the 80x60 display cache from full-resolution PSRAM data.
//
// RGB:
//   One representative RGB565 pixel per 8x8 tile.
//
// Gaussian:
//   Average of all 64 pixels in each 8x8 tile.
//
// Sobel:
//   Local adaptive gradient enhancement:
//       Max  = maximum gradient in 8x8 tile
//       Mean = average gradient in 8x8 tile
//       Contrast = Max - Mean
//
//   If Max > Mean + LOCAL_MARGIN:
//       strengthen the edge
//   else:
//       retain a weak gray response instead of forcing it to 0.
//
// This keeps gradient information and adds a lightweight
// local-adaptive enhancement without extra frame buffers.
// ============================================================

module final_psram_cache_fill (
    input  wire        clk,
    input  wire        rst_n,

    input  wire        store_done,
    input  wire        original_done,

    output wire        rd_req,
    output reg  [23:0] rd_addr,
    input  wire        rd_req_ready,
    input  wire        rd_valid,
    input  wire [7:0]  rd_data,

    output reg         rgb_valid,
    output reg  [23:0] rgb_data,

    output reg         gray_valid,
    output reg  [7:0]  gray_data,

    output reg         gauss_valid,
    output reg  [7:0]  gauss_data,

    output reg         edge_valid,
    output reg  [7:0]  edge_data,

    output wire [9:0]  sample_x,
    output wire [8:0]  sample_y,

    output reg         fill_done
);

    // ========================================================
    // State machine
    // ========================================================

    localparam [2:0]
        WAIT_WRITE = 3'd0,
        ISSUE      = 3'd1,
        WAIT_READ  = 3'd2,
        ADVANCE    = 3'd3,
        DONE       = 3'd4;

    reg [2:0] state;

    // 0 = RGB low byte
    // 1 = RGB high byte
    // 2 = Gaussian 8x8
    // 3 = Sobel gradient 8x8
    reg [2:0] plane;

    reg [6:0] col;
    reg [5:0] row;

    reg [7:0] rgb_lo;

    reg [2:0] sub_x;
    reg [2:0] sub_y;

    // Gaussian: maximum = 255 * 64 = 16320
    reg [13:0] gauss_sum;

    // Sobel local statistics
    reg [13:0] edge_sum;
    reg [7:0]  edge_max;


    // ========================================================
    // Address generation
    // ========================================================

    // Tile origin:
    //
    // x = col * 8
    // y = row * 8
    //
    // linear address:
    // y * 640 + x
    //
    // 640 = 512 + 128
    // ========================================================

    wire [18:0] tile_offset =
        ({13'd0, row} << 12) +
        ({13'd0, row} << 10) +
        ({12'd0, col} << 3);


    // Offset inside one 8x8 tile:
    //
    // sub_y * 640 + sub_x
    //
    // 640 = 512 + 128
    // ========================================================

    wire [18:0] sub_offset =
        ({16'd0, sub_y} << 9) +
        ({16'd0, sub_y} << 7) +
        {16'd0, sub_x};


    wire [18:0] pooled_offset =
        tile_offset + sub_offset;


    // RGB565 = 2 bytes / pixel
    wire [23:0] rgb_byte_offset =
        {4'd0, tile_offset, 1'b0};


    wire last_subpixel =
        (sub_x == 3'd7) &&
        (sub_y == 3'd7);


    // ========================================================
    // Gaussian averaging
    // ========================================================

    wire [13:0] gauss_sum_plus_current =
        gauss_sum + {6'd0, rd_data};


    wire [13:0] gauss_mean_wide =
        (gauss_sum_plus_current + 14'd32) >> 6;

    wire [7:0] gauss_mean =
        gauss_mean_wide[7:0];


    // ========================================================
    // Sobel local adaptive statistics
    // ========================================================

    wire [13:0] edge_sum_plus_current =
        edge_sum + {6'd0, rd_data};


    wire [7:0] edge_max_plus_current =
        (rd_data > edge_max)
        ? rd_data
        : edge_max;


    // Divide by 64 with rounding.
    wire [13:0] edge_mean_wide =
        (edge_sum_plus_current + 14'd32) >> 6;

    wire [7:0] edge_mean =
        edge_mean_wide[7:0];


    // Local contrast:
    //
    // max >= mean for a normal 8x8 population.
    //
    wire [8:0] edge_contrast_wide =
        {1'b0, edge_max_plus_current}
        -
        {1'b0, edge_mean};

    wire [7:0] edge_contrast =
        edge_contrast_wide[7:0];


    // ========================================================
    // Local adaptive threshold
    //
    // Smaller value:
    //   more weak edges retained
    //
    // Larger value:
    //   stronger noise suppression
    //
    // Start with 16.
    // ========================================================

    localparam [8:0] LOCAL_MARGIN = 9'd16;


    wire [8:0] local_threshold =
        {1'b0, edge_mean}
        +
        LOCAL_MARGIN;


    wire strong_local_edge =
        ({1'b0, edge_max_plus_current} >
         local_threshold);


    // ========================================================
    // Strong-edge enhancement
    //
    // enhanced = max + contrast / 2
    //
    // Saturate to 255.
    //
    // No multiplier / divider required.
    // ========================================================

    wire [8:0] strong_boost =
        {1'b0, edge_max_plus_current}
        +
        ({1'b0, edge_contrast} >> 2);


    wire [7:0] strong_edge_value =
        strong_boost[8]
        ? 8'hFF
        : strong_boost[7:0];


    // Weak response:
    //
    // Preserve part of the local contrast instead of forcing
    // the entire tile to black.
    //
    // contrast / 2
    //
    wire [7:0] weak_edge_value =
        {1'b0, edge_contrast[7:1]};


    wire [7:0] adaptive_edge_value =
        strong_local_edge
        ? strong_edge_value
        : weak_edge_value;


    // ========================================================
    // Display-cache coordinates
    // ========================================================

    assign sample_x = {col, 3'b000};
    assign sample_y = {row, 3'b000};

    assign rd_req = (state == ISSUE);


    // ========================================================
    // RGB565 -> RGB888
    // ========================================================

    wire [15:0] rgb565_value =
        {rd_data, rgb_lo};

    wire [4:0] r5 =
        rgb565_value[15:11];

    wire [5:0] g6 =
        rgb565_value[10:5];

    wire [4:0] b5 =
        rgb565_value[4:0];


    // ========================================================
    // PSRAM memory map
    //
    // Original RGB : 0x000000
    // Gaussian     : 0x200000
    // Sobel        : 0x300000
    // ========================================================

    always @* begin
        case (plane)

            3'd0:
                rd_addr =
                    rgb_byte_offset;

            3'd1:
                rd_addr =
                    rgb_byte_offset + 24'd1;

            3'd2:
                rd_addr =
                    24'h200000 +
                    {5'd0, pooled_offset};

            default:
                rd_addr =
                    24'h300000 +
                    {5'd0, pooled_offset};

        endcase
    end


    // ========================================================
    // Main FSM
    // ========================================================

    always @(posedge clk or negedge rst_n) begin

        if (!rst_n) begin

            state       <= WAIT_WRITE;
            plane       <= 3'd0;

            col         <= 7'd0;
            row         <= 6'd0;

            rgb_lo      <= 8'd0;

            sub_x       <= 3'd0;
            sub_y       <= 3'd0;

            gauss_sum   <= 14'd0;

            edge_sum    <= 14'd0;
            edge_max    <= 8'd0;

            rgb_valid   <= 1'b0;
            rgb_data    <= 24'd0;

            gray_valid  <= 1'b0;
            gray_data   <= 8'd0;

            gauss_valid <= 1'b0;
            gauss_data  <= 8'd0;

            edge_valid  <= 1'b0;
            edge_data   <= 8'd0;

            fill_done   <= 1'b0;

        end
        else begin

            // Valid signals are single-cycle pulses.
            rgb_valid   <= 1'b0;
            gray_valid  <= 1'b0;
            gauss_valid <= 1'b0;
            edge_valid  <= 1'b0;


            case (state)

                // ============================================
                // Wait until PSRAM writing has completed.
                // ============================================

                WAIT_WRITE: begin

                    if (store_done && original_done) begin

                        plane <= 3'd0;

                        col   <= 7'd0;
                        row   <= 6'd0;

                        sub_x <= 3'd0;
                        sub_y <= 3'd0;

                        gauss_sum <= 14'd0;

                        edge_sum  <= 14'd0;
                        edge_max  <= 8'd0;

                        state <= ISSUE;

                    end

                end


                // ============================================
                // Issue one PSRAM read request.
                // ============================================

                ISSUE: begin

                    if (rd_req_ready)
                        state <= WAIT_READ;

                end


                // ============================================
                // Wait for returned byte.
                // ============================================

                WAIT_READ: begin

                    if (rd_valid) begin

                        case (plane)

                            // =================================
                            // RGB565 low byte
                            // =================================

                            3'd0: begin

                                rgb_lo <= rd_data;

                                plane <= 3'd1;
                                state <= ISSUE;

                            end


                            // =================================
                            // RGB565 high byte
                            // =================================

                            3'd1: begin

                                rgb_data <= {
                                    {r5, r5[4:2]},
                                    {g6, g6[5:4]},
                                    {b5, b5[4:2]}
                                };

                                rgb_valid <= 1'b1;

                                plane <= 3'd2;

                                sub_x <= 3'd0;
                                sub_y <= 3'd0;

                                gauss_sum <= 14'd0;

                                state <= ISSUE;

                            end


                            // =================================
                            // Gaussian:
                            // average all 64 pixels.
                            // =================================

                            3'd2: begin

                                if (last_subpixel) begin

                                    gauss_data <= gauss_mean;
                                    gauss_valid <= 1'b1;

                                    plane <= 3'd3;

                                    sub_x <= 3'd0;
                                    sub_y <= 3'd0;

                                    edge_sum <= 14'd0;
                                    edge_max <= 8'd0;

                                    state <= ISSUE;

                                end
                                else begin

                                    gauss_sum <=
                                        gauss_sum_plus_current;

                                    if (sub_x == 3'd7) begin

                                        sub_x <= 3'd0;
                                        sub_y <= sub_y + 3'd1;

                                    end
                                    else begin

                                        sub_x <= sub_x + 3'd1;

                                    end

                                    state <= ISSUE;

                                end

                            end


                            // =================================
                            // Sobel gradient:
                            //
                            // collect:
                            //   SUM
                            //   MAX
                            //
                            // and perform local adaptive
                            // enhancement after 64 pixels.
                            // =================================

                            default: begin

                                if (last_subpixel) begin

                                    edge_data <=
                                        adaptive_edge_value;

                                    edge_valid <= 1'b1;

                                    edge_sum <= 14'd0;
                                    edge_max <= 8'd0;

                                    plane <= 3'd0;

                                    sub_x <= 3'd0;
                                    sub_y <= 3'd0;

                                    state <= ADVANCE;

                                end
                                else begin

                                    edge_sum <=
                                        edge_sum_plus_current;

                                    edge_max <=
                                        edge_max_plus_current;

                                    if (sub_x == 3'd7) begin

                                        sub_x <= 3'd0;
                                        sub_y <= sub_y + 3'd1;

                                    end
                                    else begin

                                        sub_x <= sub_x + 3'd1;

                                    end

                                    state <= ISSUE;

                                end

                            end

                        endcase

                    end

                end


                // ============================================
                // Keep tile coordinates stable during the
                // cache-write pulse, then move to next tile.
                // ============================================

                ADVANCE: begin

                    if (col == 7'd79) begin

                        col <= 7'd0;

                        if (row == 6'd59) begin

                            fill_done <= 1'b1;
                            state <= DONE;

                        end
                        else begin

                            row <= row + 6'd1;
                            state <= ISSUE;

                        end

                    end
                    else begin

                        col <= col + 7'd1;
                        state <= ISSUE;

                    end

                end


                // ============================================
                // Complete
                // ============================================

                DONE: begin
                    state <= DONE;
                end


                default: begin
                    state <= WAIT_WRITE;
                end

            endcase

        end

    end

endmodule
