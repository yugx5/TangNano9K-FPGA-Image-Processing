`timescale 1ns / 1ps
module quad_frame_cache(
    input wr_clk, rd_clk, wr_resetn, rd_resetn,
    input rgb_valid, input [9:0] rgb_x, input [8:0] rgb_y, input [23:0] rgb_data,
    input gray_valid, input [9:0] gray_x, input [8:0] gray_y, input [7:0] gray_data,
    input gauss_valid, input [9:0] gauss_x, input [8:0] gauss_y, input [7:0] gauss_data,
    input edge_valid, input [9:0] edge_x, input [8:0] edge_y, input [7:0] edge_data,
    input [12:0] rd_addr,
    input rd_en,
    output [3:0] banks_ready,
    output reg [15:0] rgb_rd,
    output wire [7:0] gray_rd,
    output reg [7:0] gauss_rd, edge_rd
);
    // 80 x 60 = 4800 pixels. Sample every eighth source pixel.
    reg [15:0] mem_rgb [0:4799] /* synthesis syn_ramstyle = "block_ram" */;
    reg [7:0] mem_gauss [0:4799] /* synthesis syn_ramstyle = "block_ram" */;
    reg [7:0] mem_edge [0:4799] /* synthesis syn_ramstyle = "block_ram" */;
    // Gray display is calculated from the cached RGB565 pixel instead of
    // storing a separate 4800x8 frame. This saves about 38.4 Kbit (~3 BSRAM).
    // Expansion and coefficients match algorithm/rgb2gray.v.
    wire [7:0] gray_r = {rgb_rd[15:11], rgb_rd[15:13]};
    wire [7:0] gray_g = {rgb_rd[10:5],  rgb_rd[10:9]};
    wire [7:0] gray_b = {rgb_rd[4:0],   rgb_rd[4:2]};
    wire [15:0] gray_r_mult = {8'd0, gray_r} * 16'd77;
    wire [15:0] gray_g_mult = {8'd0, gray_g} * 16'd150;
    wire [15:0] gray_b_mult = {8'd0, gray_b} * 16'd29;
    wire [15:0] gray_sum = gray_r_mult + gray_g_mult + gray_b_mult;
    assign gray_rd = gray_sum[15:8];

    function [12:0] idx;
        input [9:0] x;
        input [8:0] y;
        reg [5:0] yy;
        begin
            yy=y[8:3];
            idx=({7'd0,yy} << 6) + ({7'd0,yy} << 4) + {6'd0,x[9:3]};
        end
    endfunction
    reg [3:0] ready_wr;
    reg [3:0] ready_meta, ready_sync;
    assign banks_ready = ready_sync;
    // Reset both read-domain synchronizer stages synchronously to rd_clk.
    // Do not reset the frame RAM arrays (helps Gowin BSRAM inference).
    always @(posedge rd_clk) begin
        if (!rd_resetn) begin
            ready_meta <= 4'b0000;
            ready_sync <= 4'b0000;
        end else begin
            ready_meta <= ready_wr;
            ready_sync <= ready_meta;
        end
    end
    always @(posedge wr_clk or negedge wr_resetn) begin
        if (!wr_resetn) ready_wr <= 4'b0000;
        else begin
            if (rgb_valid && rgb_x==10'd632 && rgb_y==9'd472) ready_wr[0] <= 1'b1;
            // Gray is derived from the cached RGB565 sample, so its bank is ready with RGB.
            if (rgb_valid && rgb_x==10'd632 && rgb_y==9'd472) ready_wr[1] <= 1'b1;
            if (gauss_valid && gauss_x==10'd632 && gauss_y==9'd472) ready_wr[2] <= 1'b1;
            if (edge_valid && edge_x==10'd632 && edge_y==9'd472) ready_wr[3] <= 1'b1;
        end
    end
    always @(posedge wr_clk) begin
        if (wr_resetn) begin
            if (rgb_valid && rgb_x[2:0]==0 && rgb_y[2:0]==0)
                mem_rgb[idx(rgb_x,rgb_y)] <= {rgb_data[23:19],rgb_data[15:10],rgb_data[7:3]};
            if (gauss_valid && gauss_x[2:0]==0 && gauss_y[2:0]==0)
                mem_gauss[idx(gauss_x,gauss_y)] <= gauss_data;
            if (edge_valid && edge_x[2:0]==0 && edge_y[2:0]==0)
                mem_edge[idx(edge_x,edge_y)] <= edge_data;
        end
    end
    always @(posedge rd_clk) if (rd_en) begin
        rgb_rd <= mem_rgb[rd_addr];
        gauss_rd <= mem_gauss[rd_addr];
        edge_rd <= mem_edge[rd_addr];
    end
endmodule
