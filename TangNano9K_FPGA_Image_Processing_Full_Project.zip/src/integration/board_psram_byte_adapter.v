`timescale 1ns / 1ps

// ============================================================================
// board_psram_byte_adapter
//
// Clock-domain bridge + byte adapter for the verified Tang Nano 9K PSRAM
// controller.
//
// User side:    user_clk (27 MHz), BYTE address, 8-bit data.
// PSRAM side:   psram_clk (54 MHz), x16 controller with busy handshake.
//
// ============================================================================
module board_psram_byte_adapter
(
    // ---------------- user / algorithm domain ----------------
    input  wire        user_clk,
    input  wire        user_resetn,

    input  wire        wr_req,
    input  wire [23:0] wr_addr,
    input  wire [7:0]  wr_data,
    output reg         wr_ready,

    input  wire        rd_req,
    input  wire [23:0] rd_addr,
    output wire        rd_req_ready,
    output reg         rd_valid,
    output reg  [7:0]  rd_data,

    // ---------------- physical PSRAM domain -------------------
    input  wire        psram_clk,
    input  wire        psram_resetn,

    input  wire        psram_busy,
    input  wire [15:0] psram_rdata,
    output reg         psram_read,
    output reg         psram_write,
    output reg  [21:0] psram_addr,
    output reg  [15:0] psram_wdata
);

    // ------------------------------------------------------------------------
    // User-side mailbox.  Multi-bit payload is held stable from request toggle
    // until acknowledgement returns, so the synchronized toggle is the CDC
    // qualifier.
    // ------------------------------------------------------------------------
    reg        cmd_toggle_user;
    reg        cmd_is_write_user;
    reg [23:0] cmd_addr_user;
    reg [7:0]  cmd_wdata_user;

    reg ack_sync1_user, ack_sync2_user;
    reg [7:0] read_data_mailbox_sync1;
    reg [7:0] read_data_mailbox_sync2;

    localparam [1:0] U_IDLE = 2'd0;
    localparam [1:0] U_WAIT = 2'd1;
    localparam [1:0] U_PULSE = 2'd2;
    reg [1:0] user_state;
    reg       pending_is_write_user;

    assign rd_req_ready = (user_state == U_IDLE) && !wr_req;

    // Returned byte is written in psram_clk domain before ack toggles and then
    // remains stable until the next completed read.
    reg [7:0] read_data_mailbox_psram;
    reg ack_toggle_psram; // declared before user clock-domain always block

    always @(posedge user_clk or negedge user_resetn)
    begin
        if (!user_resetn)
        begin
            cmd_toggle_user          <= 1'b0;
            cmd_is_write_user        <= 1'b0;
            cmd_addr_user            <= 24'd0;
            cmd_wdata_user           <= 8'd0;

            ack_sync1_user           <= 1'b0;
            ack_sync2_user           <= 1'b0;
            read_data_mailbox_sync1  <= 8'd0;
            read_data_mailbox_sync2  <= 8'd0;

            user_state               <= U_IDLE;
            pending_is_write_user    <= 1'b0;

            wr_ready                 <= 1'b0;
            rd_valid                 <= 1'b0;
            rd_data                  <= 8'd0;
        end
        else
        begin
            ack_sync1_user          <= ack_toggle_psram;
            ack_sync2_user          <= ack_sync1_user;
            read_data_mailbox_sync1 <= read_data_mailbox_psram;
            read_data_mailbox_sync2 <= read_data_mailbox_sync1;

            wr_ready <= 1'b0;
            rd_valid <= 1'b0;

            case (user_state)
                U_IDLE:
                begin
                    // Result writer gets priority if both are asserted.
                    if (wr_req && !wr_ready)
                    begin
                        cmd_is_write_user     <= 1'b1;
                        cmd_addr_user         <= wr_addr;
                        cmd_wdata_user        <= wr_data;
                        pending_is_write_user <= 1'b1;
                        cmd_toggle_user       <= ~cmd_toggle_user;
                        user_state            <= U_WAIT;
                    end
                    else if (rd_req)
                    begin
                        cmd_is_write_user     <= 1'b0;
                        cmd_addr_user         <= rd_addr;
                        cmd_wdata_user        <= 8'd0;
                        pending_is_write_user <= 1'b0;
                        cmd_toggle_user       <= ~cmd_toggle_user;
                        user_state            <= U_WAIT;
                    end
                end

                U_WAIT:
                begin
                    if (ack_sync2_user == cmd_toggle_user)
                    begin
                        if (pending_is_write_user)
                            wr_ready <= 1'b1;
                        else
                        begin
                            rd_data  <= read_data_mailbox_sync2;
                            rd_valid <= 1'b1;
                        end

                        // Hold the completion pulse for this cycle.  Returning
                        // to IDLE on the next user clock gives the upstream
                        // writer one full edge to advance its address/FIFO.
                        user_state <= U_PULSE;
                    end
                end

                U_PULSE:
                begin
                    user_state <= U_IDLE;
                end

                default:
                    user_state <= U_IDLE;
            endcase
        end
    end

    // ------------------------------------------------------------------------
    // PSRAM-side command receiver and transaction sequencer.
    // ------------------------------------------------------------------------
    reg cmd_sync1_psram, cmd_sync2_psram, cmd_seen_psram;

    reg        active_is_write;
    reg [21:0] active_word_addr;
    reg        active_byte_sel;
    reg [7:0]  active_wdata;
    reg [15:0] rmw_word;
    reg        request_accepted;

    localparam [3:0]
        P_IDLE          = 4'd0,
        P_RD_ISSUE      = 4'd1,
        P_RD_WAIT       = 4'd2,
        P_WR_ISSUE      = 4'd3,
        P_WR_WAIT       = 4'd4;

    reg [3:0] pstate;

    always @(posedge psram_clk or negedge psram_resetn)
    begin
        if (!psram_resetn)
        begin
            cmd_sync1_psram       <= 1'b0;
            cmd_sync2_psram       <= 1'b0;
            cmd_seen_psram        <= 1'b0;
            ack_toggle_psram      <= 1'b0;

            active_is_write       <= 1'b0;
            active_word_addr      <= 22'd0;
            active_byte_sel       <= 1'b0;
            active_wdata          <= 8'd0;
            rmw_word              <= 16'd0;
            request_accepted      <= 1'b0;

            psram_read            <= 1'b0;
            psram_write           <= 1'b0;
            psram_addr            <= 22'd0;
            psram_wdata           <= 16'd0;

            read_data_mailbox_psram <= 8'd0;
            pstate                <= P_IDLE;
        end
        else
        begin
            cmd_sync1_psram <= cmd_toggle_user;
            cmd_sync2_psram <= cmd_sync1_psram;

            psram_read  <= 1'b0;
            psram_write <= 1'b0;

            case (pstate)
                P_IDLE:
                begin
                    if (cmd_sync2_psram != cmd_seen_psram)
                    begin
                        // Payload has been held stable for multiple PSRAM
                        // clocks by the time the synchronized toggle arrives.
                        active_is_write  <= cmd_is_write_user;
                        active_word_addr <= {cmd_addr_user[21:1], 1'b0};
                        active_byte_sel  <= cmd_addr_user[0];
                        active_wdata     <= cmd_wdata_user;
                        cmd_seen_psram   <= cmd_sync2_psram;
                        pstate           <= P_RD_ISSUE;
                    end
                end

                // Every byte write starts with a read (RMW).  Byte reads use
                // exactly the same physical read phase.
                P_RD_ISSUE:
                begin
                    if (!psram_busy)
                    begin
                        psram_addr       <= active_word_addr;
                        psram_read       <= 1'b1;
                        request_accepted <= 1'b0;
                        pstate           <= P_RD_WAIT;
                    end
                end

                P_RD_WAIT:
                begin
                    if (psram_busy)
                        request_accepted <= 1'b1;

                    if (request_accepted && !psram_busy)
                    begin
                        if (!active_is_write)
                        begin
                            read_data_mailbox_psram <=
                                active_byte_sel ? psram_rdata[15:8]
                                                : psram_rdata[7:0];
                            ack_toggle_psram <= cmd_seen_psram;
                            pstate <= P_IDLE;
                        end
                        else
                        begin
                            rmw_word <= active_byte_sel
                                ? {active_wdata, psram_rdata[7:0]}
                                : {psram_rdata[15:8], active_wdata};
                            pstate <= P_WR_ISSUE;
                        end
                    end
                end

                P_WR_ISSUE:
                begin
                    if (!psram_busy)
                    begin
                        psram_addr       <= active_word_addr;
                        psram_wdata      <= rmw_word;
                        psram_write      <= 1'b1;
                        request_accepted <= 1'b0;
                        pstate           <= P_WR_WAIT;
                    end
                end

                P_WR_WAIT:
                begin
                    if (psram_busy)
                        request_accepted <= 1'b1;

                    if (request_accepted && !psram_busy)
                    begin
                        ack_toggle_psram <= cmd_seen_psram;
                        pstate <= P_IDLE;
                    end
                end

                default:
                    pstate <= P_IDLE;
            endcase
        end
    end

endmodule
