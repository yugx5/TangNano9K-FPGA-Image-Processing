`timescale 1ns / 1ps
// Write an original RGB565 pixel to PSRAM BEFORE admitting it to the algorithm.
// One register-held pixel + two byte writes, so no additional BRAM/FIFO.
// Original byte layout: even address=RGB565 low byte; odd=high byte.
module final_rgb565_store_frontend (
    input wire clk,
    input wire rst_n,
    input wire clear_done,
    input wire writer_pause,
    input wire src_valid,
    input wire [23:0] src_rgb,
    input wire [9:0] src_x,
    input wire [8:0] src_y,
    output wire src_pause,
    output wire algorithm_valid,
    output wire wr_req,
    output wire [23:0] wr_addr,
    output wire [7:0] wr_data,
    input wire wr_ready,
    output reg original_done
);
    localparam [1:0] WAIT_PIXEL=2'd0, WRITE_LO=2'd1,
                     WRITE_HI=2'd2, COMMIT=2'd3;
    reg [1:0] state;
    reg [15:0] rgb565;
    reg [23:0] pixel_addr;
    wire [18:0] px_index = (({10'd0,src_y} << 9) +
                            ({10'd0,src_y} << 7)) + {9'd0,src_x};
    assign wr_req = (state == WRITE_LO || state == WRITE_HI);
    assign wr_addr = pixel_addr + ((state == WRITE_HI) ? 24'd1 : 24'd0);
    assign wr_data = (state == WRITE_HI) ? rgb565[15:8] : rgb565[7:0];
    assign algorithm_valid = state == COMMIT && src_valid && !writer_pause;
    assign src_pause = !algorithm_valid;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= WAIT_PIXEL;
            rgb565 <= 16'd0;
            pixel_addr <= 24'd0;
            original_done <= 1'b0;
        end else begin
            case (state)
                WAIT_PIXEL: if (clear_done && src_valid && !writer_pause) begin
                    rgb565 <= {src_rgb[23:19],src_rgb[15:10],src_rgb[7:3]};
                    pixel_addr <= {4'd0,px_index,1'b0};
                    state <= WRITE_LO;
                end
                WRITE_LO: if (wr_ready) state <= WRITE_HI;
                WRITE_HI: if (wr_ready) state <= COMMIT;
                COMMIT: if (algorithm_valid) begin
                    if (src_x == 10'd639 && src_y == 9'd479)
                        original_done <= 1'b1;
                    state <= WAIT_PIXEL;
                end
                default: state <= WAIT_PIXEL;
            endcase
        end
    end
endmodule
