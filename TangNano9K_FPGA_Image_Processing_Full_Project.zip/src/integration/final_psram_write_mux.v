`timescale 1ns / 1ps
// PSRAM write request holder / arbiter.
//
module final_psram_write_mux (
    input wire clk,
    input wire rst_n,

    input wire result_req,
    input wire [23:0] result_addr,
    input wire [7:0] result_data,
    output wire result_ready,

    input wire original_req,
    input wire [23:0] original_addr,
    input wire [7:0] original_data,
    output wire original_ready,

    output wire mem_req,
    output wire [23:0] mem_addr,
    output wire [7:0] mem_data,
    input wire mem_ready
);
    reg outstanding;
    reg owner_result;
    reg [23:0] held_addr;
    reg [7:0] held_data;

    assign mem_req  = outstanding;
    assign mem_addr = held_addr;
    assign mem_data = held_data;

    // Upstream producers only see completion for the request they own.
    assign result_ready   = outstanding && owner_result  && mem_ready;
    assign original_ready = outstanding && !owner_result && mem_ready;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            outstanding  <= 1'b0;
            owner_result <= 1'b1;
            held_addr    <= 24'd0;
            held_data    <= 8'd0;
        end else begin
            if (!outstanding) begin
                // Existing policy: result writer has priority.
                if (result_req) begin
                    outstanding  <= 1'b1;
                    owner_result <= 1'b1;
                    held_addr    <= result_addr;
                    held_data    <= result_data;
                end else if (original_req) begin
                    outstanding  <= 1'b1;
                    owner_result <= 1'b0;
                    held_addr    <= original_addr;
                    held_data    <= original_data;
                end
            end else if (mem_ready) begin
                // board_psram_byte_adapter has completed the held byte write.
                outstanding <= 1'b0;
            end
        end
    end
endmodule
