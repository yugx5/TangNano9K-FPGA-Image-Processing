`timescale 1ns / 1ps
module quad_video_source(
    input clk, resetn,
    output reg out_axis_tvalid,
    input out_axis_tready,
    output reg [23:0] out_axis_tdata,
    output reg [0:0] out_axis_tuser,
    output [12:0] rd_addr,
    output rd_en,
    input [3:0] banks_ready,
    input [15:0] rgb565,
    input [7:0] gray, gauss, edge_pixel
);
    reg [9:0] x;
    reg [8:0] y;
    reg [1:0] quadrant_d;
    reg sof_d, valid_d;
    reg ready_d;
    wire [9:0] local_x_wide = (x >= 10'd320) ? x-10'd320 : x;
    wire [8:0] local_x = local_x_wide[8:0];
    wire [8:0] local_y = (y >= 9'd240) ? y-9'd240 : y;
    wire [6:0] sx = local_x[8:2];
    wire [5:0] sy = local_y[7:2];
    assign rd_addr = ({7'd0,sy} << 6) + ({7'd0,sy} << 4) + {6'd0,sx};
    assign rd_en = !out_axis_tvalid || out_axis_tready;
    wire [7:0] r = {rgb565[15:11],rgb565[15:13]};
    wire [7:0] g = {rgb565[10:5],rgb565[10:9]};
    wire [7:0] b = {rgb565[4:0],rgb565[4:2]};
    reg [23:0] pixel;
    always @* begin
        if (!ready_d) pixel=24'h000000;
        else case (quadrant_d)
          2'd0: pixel={b,g,r}; // SVO expects B,G,R order
          2'd1: pixel={gray,gray,gray};
          2'd2: pixel={gauss,gauss,gauss};
          default: pixel={edge_pixel,edge_pixel,edge_pixel};
        endcase
    end
    always @(posedge clk) begin
        if (!resetn) begin
            x<=0; y<=0; quadrant_d<=0; sof_d<=0; valid_d<=0; ready_d<=0;
            out_axis_tvalid<=0; out_axis_tdata<=0; out_axis_tuser<=0;
        end else if (rd_en) begin
            // One-cycle RAM read: current registered data belongs to
            // the address issued on the preceding enabled cycle.
            out_axis_tvalid <= valid_d;
            out_axis_tdata <= pixel;
            out_axis_tuser <= sof_d;
            quadrant_d <= {y>=9'd240,x>=10'd320};
            ready_d <= banks_ready[{y>=9'd240,x>=10'd320}];
            sof_d <= (x==0 && y==0);
            valid_d <= 1'b1;
            if (x==10'd639) begin
                x<=0;
                if (y==9'd479) y<=0;
                else y<=y+1'b1;
            end else x<=x+1'b1;
        end
    end
endmodule
