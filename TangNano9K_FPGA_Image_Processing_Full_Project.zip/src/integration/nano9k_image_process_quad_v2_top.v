`timescale 1ns / 1ps

// ============================================================================
// Final integration: internal RLE-ROM RGB565 -> algorithm -> four PSRAM
// image planes -> 80x60 sampled PSRAM readback -> board-proven HDMI quadrants.
// ============================================================================
module nano9k_image_process_quad_v2_top
(
    input         sys_clk,
    input         sys_resetn,

    output        led_done_n,
    output        led_error_n,
    output        uart_txp,

    output        tmds_clk_n,
    output        tmds_clk_p,
    output [2:0]  tmds_d_n,
    output [2:0]  tmds_d_p,

    // No physical SPI Flash pins are used in this ROM-prestore build.
    output [1:0]  O_psram_ck,
    output [1:0]  O_psram_ck_n,
    inout  [1:0]  IO_psram_rwds,
    inout  [15:0] IO_psram_dq,
    output [1:0]  O_psram_reset_n,
    output [1:0]  O_psram_cs_n
);

    // ========================================================================
    // 54-MHz PSRAM physical clock domain
    // ========================================================================
    wire psram_clk;
    wire psram_clk_p;
    wire psram_pll_lock;

    Gowin_rPLL_PSRAM u_psram_pll
    (
        .clkout  (psram_clk),
        .clkoutp (psram_clk_p),
        .lock    (psram_pll_lock),
        .clkin   (sys_clk)
    );

    reg [7:0] psram_reset_pipe;
    wire psram_resetn = psram_reset_pipe[7] & sys_resetn;

    always @(posedge psram_clk or negedge psram_pll_lock)
    begin
        if (!psram_pll_lock)
            psram_reset_pipe <= 8'h00;
        else
            psram_reset_pipe <= {psram_reset_pipe[6:0], 1'b1};
    end

    assign O_psram_reset_n = {2{psram_resetn}};
    assign O_psram_ck_n    = 2'b00;

    wire        phy_busy;
    wire [15:0] phy_rdata;
    wire        phy_read;
    wire        phy_write;
    wire [21:0] phy_addr;
    wire [15:0] phy_wdata;

    psram_controller u_psram_controller
    (
        .clk             (psram_clk),
        .clk_p           (psram_clk_p),
        .resetn          (psram_resetn),

        .read            (phy_read),
        .write           (phy_write),
        .addr            (phy_addr),
        .din             (phy_wdata),
        .dout            (phy_rdata),
        .busy            (phy_busy),

        .O_psram_ck      (O_psram_ck),
        .IO_psram_rwds   (IO_psram_rwds),
        .IO_psram_dq     (IO_psram_dq),
        .O_psram_cs_n    (O_psram_cs_n)
    );

    // ========================================================================
    // 27-MHz algorithm domain reset.  Keep the final core in reset until the
    // PSRAM PLL is locked; the adapter will then wait for PSRAM init/busy.
    // ========================================================================
    reg [3:0] algo_reset_pipe;
    wire algo_resetn = algo_reset_pipe[3] & sys_resetn;

    always @(posedge sys_clk or negedge psram_pll_lock)
    begin
        if (!psram_pll_lock)
            algo_reset_pipe <= 4'b0000;
        else
            algo_reset_pipe <= {algo_reset_pipe[2:0], 1'b1};
    end

    // ========================================================================
    // Existing optimized algorithm + Stage-3 final result store writer.
    // ========================================================================
    wire [23:0] src_rgb;
    wire        src_valid;
    wire [9:0]  src_x;
    wire [8:0]  src_y;
    wire        src_frame_sent;

    wire        source_pause;
    wire        src_pause;
    wire        flash_to_store_commit;
    wire        original_done;
    wire        algorithm_frame_sent;
    wire [23:0] algo_rgb;
    wire        algo_valid;
    wire [9:0]  algo_x;
    wire [8:0]  algo_y;
    wire        clear_done;
    wire        store_done;

    wire        store_wr_req;
    wire [23:0] store_wr_addr;
    wire [7:0]  store_wr_data;
    wire        store_wr_ready;

    wire [31:0] clear_write_count;
    wire [31:0] gray_write_count;
    wire [31:0] gauss_write_count;
    wire [31:0] edge_write_count;
    wire [7:0]  max_gray_fifo;
    wire [7:0]  max_gauss_fifo;
    wire [7:0]  max_edge_fifo;
    wire        fifo_overflow;

    wire [7:0] dbg_gray;
    wire       dbg_gray_valid;
    wire [9:0] dbg_gray_x;
    wire [8:0] dbg_gray_y;

    wire [7:0] dbg_gauss;
    wire       dbg_gauss_valid;
    wire [9:0] dbg_gauss_x;
    wire [8:0] dbg_gauss_y;

    wire [7:0] dbg_edge;
    wire       dbg_edge_valid;
    wire [9:0] dbg_edge_x;
    wire [8:0] dbg_edge_y;

    final_spi_flash_rgb565_source #(
        .FLASH_BYTE_ADDR(24'h100000)
    ) u_source (
        .clk(sys_clk), .rst_n(algo_resetn), .enable(clear_done),
        .pause(src_pause),
        .rgb(src_rgb), .valid(src_valid), .x(src_x), .y(src_y),
        .frame_sent(src_frame_sent),
        .flash_sclk(), .flash_cs_n(),
        .flash_mosi(), .flash_miso(1'b1)
    );

    wire orig_wr_req;
    wire [23:0] orig_wr_addr;
    wire [7:0] orig_wr_data;
    wire orig_wr_ready;
    final_rgb565_store_frontend u_original_store (
        .clk(sys_clk), .rst_n(algo_resetn),
        .clear_done(clear_done), .writer_pause(source_pause),
        .src_valid(src_valid), .src_rgb(src_rgb), .src_x(src_x), .src_y(src_y),
        .src_pause(src_pause), .algorithm_valid(flash_to_store_commit),
        .wr_req(orig_wr_req), .wr_addr(orig_wr_addr),
        .wr_data(orig_wr_data), .wr_ready(orig_wr_ready),
        .original_done(original_done)
    );

    final_compute_store_top u_final_compute_store
    (
        .clk              (sys_clk),
        .rst_n            (algo_resetn),

        .rgb_in           (algo_rgb),
        .in_valid         (algo_valid),
        .in_x             (algo_x),
        .in_y             (algo_y),
        .threshold        (8'd16),

        .source_pause     (source_pause),
        .clear_done       (clear_done),
        .store_done       (store_done),

        .mem_wr_req       (store_wr_req),
        .mem_wr_addr      (store_wr_addr),
        .mem_wr_data      (store_wr_data),
        .mem_wr_ready     (store_wr_ready),

        .clear_write_count(clear_write_count),
        .gray_write_count (gray_write_count),
        .gauss_write_count(gauss_write_count),
        .edge_write_count (edge_write_count),

        .max_gray_fifo    (max_gray_fifo),
        .max_gauss_fifo   (max_gauss_fifo),
        .max_edge_fifo    (max_edge_fifo),
        .fifo_overflow    (fifo_overflow),

        .dbg_gray         (dbg_gray),
        .dbg_gray_valid   (dbg_gray_valid),
        .dbg_gray_x       (dbg_gray_x),
        .dbg_gray_y       (dbg_gray_y),

        .dbg_gauss        (dbg_gauss),
        .dbg_gauss_valid  (dbg_gauss_valid),
        .dbg_gauss_x      (dbg_gauss_x),
        .dbg_gauss_y      (dbg_gauss_y),

        .dbg_edge         (dbg_edge),
        .dbg_edge_valid   (dbg_edge_valid),
        .dbg_edge_x       (dbg_edge_x),
        .dbg_edge_y       (dbg_edge_y)
    );

    // ========================================================================
    // 27-MHz two-writer arbiter and post-store PSRAM framebuffer readback.
    // No physical PSRAM/HDMI controller changes.
    // ========================================================================
    wire        byte_rd_req_ready;
    wire        byte_rd_valid;
    wire [7:0]  byte_rd_data;
    wire        byte_wr_ready;
    wire        byte_wr_req;
    wire [23:0] byte_wr_addr;
    wire [7:0]  byte_wr_data;

    final_psram_write_mux u_write_mux (
        .clk(sys_clk), .rst_n(algo_resetn),
        .result_req(store_wr_req), .result_addr(store_wr_addr),
        .result_data(store_wr_data), .result_ready(store_wr_ready),
        .original_req(orig_wr_req), .original_addr(orig_wr_addr),
        .original_data(orig_wr_data), .original_ready(orig_wr_ready),
        .mem_req(byte_wr_req), .mem_addr(byte_wr_addr),
        .mem_data(byte_wr_data), .mem_ready(byte_wr_ready)
    );

    // Read the ORIGINAL RGB565 frame through the PSRAM byte adapter BEFORE
    // delivering pixels to the existing algorithm RTL.
    wire algo_rd_req;
    wire [23:0] algo_rd_addr;
    wire algo_rd_ready;
    wire algo_rd_valid;
    wire fill_rd_ready;
    wire fill_rd_valid;
    final_psram_rgb_algorithm_source u_psram_algorithm_input (
        .clk(sys_clk), .rst_n(algo_resetn),
        .original_done(original_done), .pause(source_pause),
        .rd_req(algo_rd_req), .rd_addr(algo_rd_addr),
        .rd_req_ready(algo_rd_ready),
        .rd_valid(algo_rd_valid), .rd_data(byte_rd_data),
        .rgb(algo_rgb), .valid(algo_valid),
        .x(algo_x), .y(algo_y), .frame_done(algorithm_frame_sent)
    );
    wire fill_rd_req;
    wire [23:0] fill_rd_addr;
    wire fill_done;
    wire fill_rgb_valid, fill_gray_valid, fill_gauss_valid, fill_edge_valid;
    wire [23:0] fill_rgb_data;
    wire [7:0] fill_gray_data, fill_gauss_data, fill_edge_data;
    wire [9:0] fill_x;
    wire [8:0] fill_y;

    final_psram_cache_fill u_cache_fill (
        .clk(sys_clk), .rst_n(algo_resetn),
        .store_done(store_done), .original_done(original_done),
        .rd_req(fill_rd_req), .rd_addr(fill_rd_addr),
        .rd_req_ready(fill_rd_ready),
        .rd_valid(fill_rd_valid), .rd_data(byte_rd_data),
        .rgb_valid(fill_rgb_valid), .rgb_data(fill_rgb_data),
        .gray_valid(fill_gray_valid), .gray_data(fill_gray_data),
        .gauss_valid(fill_gauss_valid), .gauss_data(fill_gauss_data),
        .edge_valid(fill_edge_valid), .edge_data(fill_edge_data),
        .sample_x(fill_x), .sample_y(fill_y), .fill_done(fill_done)
    );

    // The two PSRAM readers never overlap: image source finishes first;
    // then algorithms drain their result writes; only then the cache fills.
    assign fill_rd_ready = algorithm_frame_sent && byte_rd_req_ready;
    assign fill_rd_valid = algorithm_frame_sent && byte_rd_valid;
    assign algo_rd_ready = !algorithm_frame_sent && byte_rd_req_ready;
    assign algo_rd_valid = !algorithm_frame_sent && byte_rd_valid;
    wire combined_rd_req = !algorithm_frame_sent ? algo_rd_req : fill_rd_req;
    wire [23:0] combined_rd_addr =
        !algorithm_frame_sent ? algo_rd_addr : fill_rd_addr;

    board_psram_byte_adapter u_board_psram_adapter
    (
        .user_clk       (sys_clk),
        .user_resetn    (algo_resetn),

        .wr_req         (byte_wr_req),
        .wr_addr        (byte_wr_addr),
        .wr_data        (byte_wr_data),
        .wr_ready       (byte_wr_ready),

        .rd_req         (combined_rd_req),
        .rd_addr        (combined_rd_addr),
        .rd_req_ready   (byte_rd_req_ready),
        .rd_valid       (byte_rd_valid),
        .rd_data        (byte_rd_data),

        .psram_clk      (psram_clk),
        .psram_resetn   (psram_resetn),

        .psram_busy     (phy_busy),
        .psram_rdata    (phy_rdata),
        .psram_read     (phy_read),
        .psram_write    (phy_write),
        .psram_addr     (phy_addr),
        .psram_wdata    (phy_wdata)
    );

    // R5 DIAGNOSTIC ONLY -- never substitutes the real Flash/PSRAM/algorithm.
    // Serial codes at 115200 8N1, about one character per second:
    // 0: waiting for PSRAM clear, C: clear completed,
    // P: full original frame stored, A: algorithm frame accepted,
    // S: result frames stored, D: all four sampled caches filled,
    // F: pixel (3,0) from ROM differs from the real test01 RGB565 image,
    // E: at least one algorithm result FIFO overflowed.
    wire debug_uart_tx;
    wire debug_flash_bad;
    wire flash_pixel3_accepted =
        src_valid && !src_pause &&
        (src_x == 10'd3) && (src_y == 9'd0);

    r5_status_uart u_r5_status_uart (
        .clk(sys_clk), .resetn(algo_resetn),
        .clear_done(clear_done), .original_done(original_done),
        .algorithm_frame_sent(algorithm_frame_sent),
        .store_done(store_done), .fill_done(fill_done),
        .fifo_overflow(fifo_overflow),
        .flash_probe_valid(flash_pixel3_accepted),
        .flash_probe_rgb(src_rgb),
        .uart_tx(debug_uart_tx),
        .flash_bad(debug_flash_bad)
    );

    // Existing DONE LED remains unchanged.
    // ERROR LED additionally catches a definite source-pixel mismatch.
    assign led_done_n  = ~fill_done;
    assign led_error_n = ~(fifo_overflow | debug_flash_bad);
    assign uart_txp = debug_uart_tx;

    // ========================================================================
    // Board-proven PLL/TMDS path, now driven by the 4-quadrant pixel stream.
    // ========================================================================
    wire hdmi_clk_5x;
    wire hdmi_clk_pixel;
    wire hdmi_pll_lock;
    wire hdmi_resetn;

    Gowin_rPLL_HDMI u_hdmi_pll
    (
        .clkin  (sys_clk),
        .clkout (hdmi_clk_5x),
        .lock   (hdmi_pll_lock)
    );

    Gowin_CLKDIV_HDMI u_hdmi_clkdiv
    (
        .clkout (hdmi_clk_pixel),
        .hclkin (hdmi_clk_5x),
        .resetn (hdmi_pll_lock)
    );

    Reset_Sync_Final_HDMI u_hdmi_reset_sync
    (
        .resetn    (hdmi_resetn),
        .ext_reset (sys_resetn & hdmi_pll_lock),
        .clk       (hdmi_clk_pixel)
    );

    // Cache synchronizer reset is synchronous to the HDMI pixel clock.
    // ready_wr already resets in the sys_clk domain; its value (including
    // reset to zero) is transported via ready_meta -> ready_sync.
    wire quad_rd_resetn = hdmi_resetn;

    wire [12:0] quad_rd_addr;
    wire quad_rd_en;
    wire [3:0] quad_banks_ready;
    wire [15:0] quad_rgb;
    wire [7:0] quad_gray, quad_gauss, quad_edge;

    quad_frame_cache u_quad_cache (
        .wr_clk(sys_clk),
        .rd_clk(hdmi_clk_pixel),
        .wr_resetn(algo_resetn),
        .rd_resetn(quad_rd_resetn),
        .rgb_valid(fill_rgb_valid), .rgb_x(fill_x), .rgb_y(fill_y), .rgb_data(fill_rgb_data),
        .gray_valid(fill_gray_valid), .gray_x(fill_x), .gray_y(fill_y), .gray_data(fill_gray_data),
        .gauss_valid(fill_gauss_valid), .gauss_x(fill_x), .gauss_y(fill_y), .gauss_data(fill_gauss_data),
        .edge_valid(fill_edge_valid), .edge_x(fill_x), .edge_y(fill_y), .edge_data(fill_edge_data),
        .rd_addr(quad_rd_addr), .rd_en(quad_rd_en),
        .banks_ready(quad_banks_ready),
        .rgb_rd(quad_rgb), .gray_rd(quad_gray), .gauss_rd(quad_gauss), .edge_rd(quad_edge)
    );
    svo_hdmi u_hdmi
    (
        .clk          (hdmi_clk_pixel),
        .resetn       (hdmi_resetn),

        .clk_pixel    (hdmi_clk_pixel),
        .clk_5x_pixel (hdmi_clk_5x),
        .locked       (hdmi_pll_lock),
        .quad_rd_addr(quad_rd_addr),
        .quad_rd_en(quad_rd_en),
        .quad_banks_ready(quad_banks_ready),
        .quad_rgb(quad_rgb),
        .quad_gray(quad_gray),
        .quad_gauss(quad_gauss),
        .quad_edge(quad_edge),

        .tmds_clk_n   (tmds_clk_n),
        .tmds_clk_p   (tmds_clk_p),
        .tmds_d_n     (tmds_d_n),
        .tmds_d_p     (tmds_d_p)
    );

endmodule


module Reset_Sync_Final_HDMI
(
    input  wire clk,
    input  wire ext_reset,
    output wire resetn
);
    reg [3:0] reset_cnt = 4'b0000;

    always @(posedge clk or negedge ext_reset)
    begin
        if (!ext_reset)
            reset_cnt <= 4'b0000;
        else
            reset_cnt <= reset_cnt + !resetn;
    end

    assign resetn = &reset_cnt;

endmodule

module r5_status_uart #(
    parameter integer CLK_HZ = 27000000,
    parameter integer REPORT_CLKS = 27000000
)(
    input  wire clk,
    input  wire resetn,
    input  wire clear_done,
    input  wire original_done,
    input  wire algorithm_frame_sent,
    input  wire store_done,
    input  wire fill_done,
    input  wire fifo_overflow,
    input  wire flash_probe_valid,
    input  wire [23:0] flash_probe_rgb,
    output wire uart_tx,
    output wire flash_bad
);

    reg flash_probe_seen;
    reg flash_probe_ok;

    always @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            flash_probe_seen <= 1'b0;
            flash_probe_ok   <= 1'b0;
        end else if (flash_probe_valid && !flash_probe_seen) begin
            flash_probe_seen <= 1'b1;
            flash_probe_ok <= (flash_probe_rgb == 24'h181C18);
        end
    end

    assign flash_bad = flash_probe_seen && !flash_probe_ok;

    reg [24:0] report_counter;
    wire report_tick = report_counter == REPORT_CLKS - 1;

    // Priority: error -> input mismatch -> most recently completed stage.
    wire [7:0] status_char =
        fifo_overflow        ? 8'h45 :  // E
        flash_bad            ? 8'h46 :  // F
        fill_done            ? 8'h44 :  // D
        store_done           ? 8'h53 :  // S
        algorithm_frame_sent ? 8'h41 :  // A
        original_done        ? 8'h50 :  // P
        clear_done           ? 8'h43 :  // C
                               8'h30;   // 0

    wire tx_ready;
    reg tx_valid;
    reg [7:0] tx_data;
    uart_tx #(.CLK_HZ(CLK_HZ), .BAUD(115200)) u_status_tx (
        .clk(clk), .resetn(resetn),
        .data(tx_data), .valid(tx_valid),
        .ready(tx_ready), .tx(uart_tx)
    );

    always @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            report_counter <= 25'd0;
            tx_valid <= 1'b0;
            tx_data <= 8'h30;
        end else begin
            tx_valid <= 1'b0;
            if (report_tick) begin
                report_counter <= 25'd0;
                if (tx_ready) begin
                    tx_data <= status_char;
                    tx_valid <= 1'b1;
                end
            end else begin
                report_counter <= report_counter + 1'b1;
            end
        end
    end
endmodule
