// timing constraints.
// 27-MHz board oscillator.
create_clock -name sys_clk -period 37.037 -waveform {0 18.518} [get_ports {sys_clk}]

// PSRAM operating clock.

create_clock -name psram_clk -period 18.519 [get_nets {psram_clk}]

# HDMI pixel clock: CLKDIV divides the 5x clock by 5.

# HDMI PLL output: 27 MHz * 14 / 3 = 126 MHz.
create_generated_clock -name hdmi_clk_5x -master_clock sys_clk -source [get_ports {sys_clk}] -multiply_by 14 -divide_by 3 [get_pins {u_hdmi_pll/rpll_inst/CLKOUT}]

# HDMI pixel clock: 126 MHz / 5 = 25.2 MHz.
create_generated_clock -name hdmi_clk_pixel -master_clock hdmi_clk_5x -source [get_pins {u_hdmi_pll/rpll_inst/CLKOUT}] -divide_by 5 [get_pins {u_hdmi_clkdiv/clkdiv_inst/CLKOUT}]
# CDC first-stage acknowledgement exception.
set_false_path -from [get_regs {u_board_psram_adapter/ack_toggle_psram_s4}] -to [get_regs {u_board_psram_adapter/ack_sync1_user_s0}]


# PSRAM read-data mailbox CDC.
# Exclude only mailbox_psram -> first-stage sync1 paths.
# Keep sync1 -> sync2 timed normally.

set_false_path -from [get_regs {u_board_psram_adapter/read_data_mailbox_psram_0_s0}] -to [get_pins {u_board_psram_adapter/read_data_mailbox_sync1_0_s8/DI[0]}]
set_false_path -from [get_regs {u_board_psram_adapter/read_data_mailbox_psram_1_s0}] -to [get_pins {u_board_psram_adapter/read_data_mailbox_sync1_0_s8/DI[1]}]
set_false_path -from [get_regs {u_board_psram_adapter/read_data_mailbox_psram_2_s0}] -to [get_pins {u_board_psram_adapter/read_data_mailbox_sync1_0_s8/DI[2]}]
set_false_path -from [get_regs {u_board_psram_adapter/read_data_mailbox_psram_3_s0}] -to [get_pins {u_board_psram_adapter/read_data_mailbox_sync1_0_s8/DI[3]}]
set_false_path -from [get_regs {u_board_psram_adapter/read_data_mailbox_psram_4_s0}] -to [get_pins {u_board_psram_adapter/read_data_mailbox_sync1_0_s10/DI[0]}]
set_false_path -from [get_regs {u_board_psram_adapter/read_data_mailbox_psram_5_s0}] -to [get_pins {u_board_psram_adapter/read_data_mailbox_sync1_0_s10/DI[1]}]
set_false_path -from [get_regs {u_board_psram_adapter/read_data_mailbox_psram_6_s0}] -to [get_pins {u_board_psram_adapter/read_data_mailbox_sync1_0_s10/DI[2]}]
set_false_path -from [get_regs {u_board_psram_adapter/read_data_mailbox_psram_7_s0}] -to [get_pins {u_board_psram_adapter/read_data_mailbox_sync1_0_s10/DI[3]}]

# The ready flag is transferred from sys_clk to HDMI pixel clock by
# ready_meta (first stage) and ready_sync (second stage).  Only the
# asynchronous FIRST-STAGE path is exempted from setup/hold analysis.
# Constraints for the first-stage CDC synchronizers.
# Do NOT exempt ready_meta -> ready_sync, or all sys/HDMI clock paths.
# CDC: sys_clk ready flags to the first synchronizer stage only.
set_false_path -from [get_pins {u_quad_cache/ready_wr_2_s0/Q}] -to [get_pins {u_quad_cache/ready_meta_2_s0/D}]
set_false_path -from [get_pins {u_quad_cache/ready_wr_1_s0/Q}] -to [get_pins {u_quad_cache/ready_meta_1_s0/D}]
set_false_path -from [get_pins {u_quad_cache/ready_wr_3_s0/Q}] -to [get_pins {u_quad_cache/ready_meta_3_s0/D}]