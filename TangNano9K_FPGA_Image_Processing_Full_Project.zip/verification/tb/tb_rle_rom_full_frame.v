`timescale 1ns/1ps
// Exact 307200-pixel ROM-source test, with deterministic stalling and
// real RGB565 image words. Independent of external Flash/PSRAM hardware.
module tb_rle_rom_full_frame;
    reg clk=1'b0;
    always #18.5185 clk=~clk; // 27 MHz
    reg rst_n=1'b0;
    reg enable=1'b0;
    reg pause=1'b1;
    wire [23:0] rgb;
    wire valid;
    wire [9:0] x;
    wire [8:0] y;
    wire frame_sent, flash_cs_n, flash_sclk, flash_mosi;
    reg [15:0] golden[0:307199];
    integer cycles=0, accepted=0, pause_cycles=0;
    integer idx;
    reg [15:0] word565;
    reg [23:0] expanded;

    final_spi_flash_rgb565_source dut (
        .clk(clk),.rst_n(rst_n),.enable(enable),.pause(pause),
        .rgb(rgb),.valid(valid),.x(x),.y(y),.frame_sent(frame_sent),
        .flash_cs_n(flash_cs_n),.flash_sclk(flash_sclk),
        .flash_mosi(flash_mosi),.flash_miso(1'b1)
    );

    initial begin
        $readmemh("image_data/test01_RGB565_WORDS_640x480.hex", golden);
        repeat(8) @(negedge clk);
        rst_n=1'b1;
        repeat(8) @(negedge clk);
        enable=1'b1;
    end

    always @(negedge clk) begin
        cycles=cycles+1;
        pause=((cycles % 13)<5)||((cycles % 31)==10);
        if (cycles>600000) $fatal(1,"ROM timeout, accepted=%0d",accepted);
    end

    always @(posedge clk) if (rst_n && enable) begin
        if (flash_cs_n!==1'b1 || flash_sclk!==1'b0 ||
            flash_mosi!==1'b0) $fatal(1,"External SPI Flash must remain idle");
        if (frame_sent && accepted!=307200)
            $fatal(1,"Frame finished too early: accepted=%0d",accepted);
        if (valid) begin
            idx=accepted;
            if (idx>=307200) $fatal(1,"More than 307200 pixels emitted");
            word565=golden[idx];
            expanded={
                word565[15:11],word565[15:13],
                word565[10:5], word565[10:9],
                word565[4:0],  word565[4:2]
            };
            if (x !== (idx % 640) || y !== (idx / 640) || rgb !== expanded) begin
                $display("FAIL ROM pixel %0d: got (%0d,%0d) rgb=%h, expected (%0d,%0d) rgb=%h",
                         idx,x,y,rgb,idx%640,idx/640,expanded);
                $fatal(1);
            end
            if (pause) pause_cycles=pause_cycles+1;
            else accepted=accepted+1;
        end
    end

    initial begin
        wait(frame_sent);
        @(negedge clk);
        if (accepted!==307200) $fatal(1,"Bad pixel count: %0d",accepted);
        if (pause_cycles<1000) $fatal(1,"Not enough backpressure");
        if (valid!==1'b0) $fatal(1,"valid still high after end of frame");
        $display("PASS ROM FULL FRAME: 307200/307200 RGB565 pixels, 0 mismatches, %0d stall cycles, external Flash idle",pause_cycles);
        $finish;
    end
endmodule
