`timescale 1ns / 1ps
// Standalone, self-checking integration TB for quad_frame_cache +
// quad_video_source. Run in SystemVerilog mode to enable $fatal.
// Uses two independent clocks, four distinguishable positional patterns,
// one entire 640x480 displayed frame, and deterministic backpressure bursts.
module tb_quad_v2;
    reg wr_clk = 0;
    reg pix_clk = 0;
    always #18 wr_clk = ~wr_clk;   // ~27.78 MHz write domain
    always #20 pix_clk = ~pix_clk; // 25 MHz display domain

    reg wr_resetn = 0;
    reg rd_resetn = 0;
    reg video_resetn = 0;
    reg [9:0] wx = 0;
    reg [8:0] wy = 0;
    reg rgbv = 0, gv = 0, av = 0, ev = 0;
    reg sink_ready = 1;
    reg run_stalls = 0;

    wire [12:0] rd_addr;
    wire rd_en;
    wire [3:0] banks_ready;
    wire [15:0] rgb_rd;
    wire [7:0] gray_rd, gauss_rd, edge_rd;
    wire axis_valid;
    wire [23:0] axis_data;
    wire [0:0] axis_sof;

    // Each bank stores an unrelated image, varied with x/y to catch
    // address aliasing, quadrant swaps, RGB byte order, and 4x scaling.
    function [7:0] r_pat;
        input integer ix, iy;
        begin r_pat = ix * 3 + iy * 5 + 8'h39; end
    endfunction
    function [7:0] g_pat;
        input integer ix, iy;
        begin g_pat = ix * 7 + iy * 2 + 8'h17; end
    endfunction
    function [7:0] b_pat;
        input integer ix, iy;
        begin b_pat = ix * 11 + iy * 13 + 8'h65; end
    endfunction
    function [7:0] gray_pat;
        input integer ix, iy;
        begin gray_pat = ix * 5 + iy * 9 + 8'h25; end
    endfunction
    function [7:0] gauss_pat;
        input integer ix, iy;
        begin gauss_pat = ix * 13 + iy * 3 + 8'h81; end
    endfunction
    function [7:0] edge_pat;
        input integer ix, iy;
        begin
            edge_pat = ((ix % 11) == 0 || (iy % 13) == 0 ||
                        ((ix + iy) % 17) == 0) ? 8'hFF : 8'h00;
        end
    endfunction

    wire [23:0] rgb_write = {r_pat(wx >> 3, wy >> 3),
                             g_pat(wx >> 3, wy >> 3),
                             b_pat(wx >> 3, wy >> 3)};
    wire [7:0] gray_write = gray_pat(wx >> 3, wy >> 3);
    wire [7:0] gauss_write = gauss_pat(wx >> 3, wy >> 3);
    wire [7:0] edge_write = edge_pat(wx >> 3, wy >> 3);

    quad_frame_cache u_cache (
        .wr_clk(wr_clk), .rd_clk(pix_clk),
        .wr_resetn(wr_resetn), .rd_resetn(rd_resetn),
        .rgb_valid(rgbv), .rgb_x(wx), .rgb_y(wy), .rgb_data(rgb_write),
        .gray_valid(gv), .gray_x(wx), .gray_y(wy), .gray_data(gray_write),
        .gauss_valid(av), .gauss_x(wx), .gauss_y(wy), .gauss_data(gauss_write),
        .edge_valid(ev), .edge_x(wx), .edge_y(wy), .edge_data(edge_write),
        .rd_addr(rd_addr), .rd_en(rd_en), .banks_ready(banks_ready),
        .rgb_rd(rgb_rd), .gray_rd(gray_rd),
        .gauss_rd(gauss_rd), .edge_rd(edge_rd)
    );

    quad_video_source u_video (
        .clk(pix_clk), .resetn(video_resetn),
        .out_axis_tvalid(axis_valid), .out_axis_tready(sink_ready),
        .out_axis_tdata(axis_data), .out_axis_tuser(axis_sof),
        .rd_addr(rd_addr), .rd_en(rd_en), .banks_ready(banks_ready),
        .rgb565(rgb_rd), .gray(gray_rd), .gauss(gauss_rd),
        .edge_pixel(edge_rd)
    );

    // Expected BGR888 from the *independent* formulas above; do not use
    // the DUT's address arithmetic to derive expected pixel positions.
    function [23:0] expected_pixel;
        input integer px, py;
        integer ix, iy;
        reg [7:0] rr, gg, bb, mono;
        reg [15:0] rgb565;
        begin
            ix = (px % 320) / 4;
            iy = (py % 240) / 4;
            rr = r_pat(ix, iy);
            gg = g_pat(ix, iy);
            bb = b_pat(ix, iy);
            rgb565 = {rr[7:3], gg[7:2], bb[7:3]};
            if (py < 240 && px < 320)
                expected_pixel = {
                    rgb565[4:0],rgb565[4:2],
                    rgb565[10:5],rgb565[10:9],
                    rgb565[15:11],rgb565[15:13]
                };
            else begin
                if (py < 240)
                    mono = gray_pat(ix, iy);
                else if (px < 320)
                    mono = gauss_pat(ix, iy);
                else
                    mono = edge_pat(ix, iy);
                expected_pixel = {mono,mono,mono};
            end
        end
    endfunction

    integer errors = 0;
    integer pixel_index = 0;
    integer stall_cycles = 0;
    integer burst_counter = 0;
    integer addr_checks = 0;
    integer actual_addr = 0;
    integer expected_addr = 0;
    reg started = 0;
    reg finished = 0;
    reg was_stalled = 0;
    reg [23:0] previous_data;
    reg [0:0] previous_sof;
    reg [23:0] target;
    integer check_x, check_y;

    task report_error;
        input [8*100-1:0] msg;
        begin
            if (errors < 15) $display("FAIL: %0s at sim time %0t", msg, $time);
            errors = errors + 1;
        end
    endtask

    // Deterministic stalls, including groups of consecutive stall cycles.
    always @(negedge pix_clk) begin
        if (!video_resetn || !run_stalls) begin
            sink_ready = 1'b1;
        end else begin
            burst_counter = burst_counter + 1;
            sink_ready = !((burst_counter % 29 < 7) ||
                           (burst_counter % 103 >= 97));
        end
    end

    // Stream checker samples signals BEFORE the active edge, just as a
    // receiving AXI-stream endpoint would. This avoids NBA testbench races.
    always @(posedge pix_clk) begin
        if (!video_resetn) begin
            was_stalled = 0;
            started = 0;
            pixel_index = 0;
        end else begin
            if (was_stalled && (axis_valid !== 1'b1 ||
                                axis_data !== previous_data ||
                                axis_sof !== previous_sof))
                report_error("AXI-stream data/valid/SOF changed while stalled");

            was_stalled = (axis_valid === 1'b1 && sink_ready === 1'b0);
            previous_data = axis_data;
            previous_sof = axis_sof;
            if (axis_valid && !sink_ready) stall_cycles = stall_cycles + 1;
            if (axis_valid && !sink_ready && rd_en !== 1'b0)
                report_error("Frame RAM read continued during AXI backpressure");

            if (rd_en && !finished) begin
                // Covers 319->320, 239->240, 639->0, and all other locations.
                actual_addr = rd_addr;
                expected_addr = ((u_video.y % 240) / 4) * 80 +
                                ((u_video.x % 320) / 4);
                if (actual_addr !== expected_addr)
                    report_error("Incorrect frame RAM read address");
                addr_checks = addr_checks + 1;
            end

            if (axis_valid && sink_ready && banks_ready === 4'b1111) begin
                if (!started && axis_sof === 1'b1) begin
                    started = 1;
                    pixel_index = 0;
                end
                if (started && !finished) begin
                    check_x = pixel_index % 640;
                    check_y = pixel_index / 640;
                    target = expected_pixel(check_x, check_y);
                    if (axis_data !== target) begin
                        if (errors < 15)
                            $display("  pixel index=%0d (%0d,%0d), got=%h expected=%h",
                                     pixel_index,check_x,check_y,axis_data,target);
                        report_error("Wrong pixel value / quadrant / pipeline alignment");
                    end
                    if (axis_sof !== (pixel_index == 0))
                        report_error("Frame SOF misplaced");
                    pixel_index = pixel_index + 1;
                    if (pixel_index == 307200) finished = 1;
                end
            end
        end
    end

    // Source writes all 4800 sampled positions to 4 different RAM banks.
    // Terminal sample can be selectively enabled to verify per-bank ready.
    task send_sample;
        input integer ix, iy;
        input [3:0] mask;
        begin
            @(negedge wr_clk);
            wx = ix * 8;
            wy = iy * 8;
            rgbv = mask[0];
            gv   = mask[1];
            av   = mask[2];
            ev   = mask[3];
        end
    endtask
    task check_ready;
        input [3:0] exp;
        begin
            repeat (5) @(negedge pix_clk);
            if (banks_ready !== exp) begin
                $display("  banks_ready=%b, expected=%b",banks_ready,exp);
                report_error("Wrong per-bank readiness");
            end
        end
    endtask

    integer xi, yi;
    initial begin
        repeat (6) @(negedge pix_clk);
        wr_resetn = 1;
        rd_resetn = 1;
        video_resetn = 1;
        repeat (18) @(negedge pix_clk);
        if (banks_ready !== 4'b0000)
            report_error("Ready nonzero before any frame bank was filled");
        if (axis_valid && axis_data !== 24'h000000)
            report_error("Uninitialized RAM pixel visible before bank ready");

        for (yi = 0; yi < 60; yi = yi + 1)
            for (xi = 0; xi < 80; xi = xi + 1)
                if (!(xi == 79 && yi == 59))
                    send_sample(xi, yi, 4'b1111);
        @(negedge wr_clk);
        rgbv = 0; gv = 0; av = 0; ev = 0;
        check_ready(4'b0000);

        send_sample(79,59,4'b0001);
        @(negedge wr_clk); rgbv = 0;
        check_ready(4'b0001);
        send_sample(79,59,4'b0010);
        @(negedge wr_clk); gv = 0;
        check_ready(4'b0011);
        send_sample(79,59,4'b0100);
        @(negedge wr_clk); av = 0;
        check_ready(4'b0111);
        send_sample(79,59,4'b1000);
        @(negedge wr_clk); ev = 0;
        check_ready(4'b1111);

        // Explicit reset test: assert read-domain reset after all writes.
        // Ready MUST immediately clear; memory itself is intentionally kept.
        @(negedge pix_clk);
        rd_resetn = 0;
        video_resetn = 0;
        @(negedge pix_clk);  // synchronous reset is applied at posedge
        if (banks_ready !== 4'b0000)
            report_error("Pixel-domain ready flags did not clear on reset");
        repeat (4) @(negedge pix_clk);
        rd_resetn = 1;
        repeat (5) @(negedge pix_clk);
        if (banks_ready !== 4'b1111)
            report_error("Pixel-domain ready flags did not resynchronize");

        // Restart video only after synchronized read-ready flags are high:
        // scoreboard sees a complete frame, rather than a partly-black boot.
        video_resetn = 1;
        run_stalls = 1;
        wait (finished);
        #1;
        if (pixel_index !== 307200)
            report_error("Did not check exactly 640x480 pixels");
        if (stall_cycles < 1000)
            report_error("Backpressure not exercised adequately");
        if (addr_checks < 307200)
            report_error("Insufficient independent read-address checks");
        if (errors == 0)
            $display("PASS tb_quad_v2: 307200 expected pixels, %0d stalls, %0d address checks, per-bank ready, pixel-clock reset",stall_cycles,addr_checks);
        else
            $fatal(1,"FAIL tb_quad_v2: %0d errors", errors);
        $finish;
    end

    initial begin
        #100000000;
        $fatal(1,"FAIL tb_quad_v2: timeout, processed pixels=%0d",pixel_index);
    end
endmodule
