`timescale 1ns / 1ps
// Image-processing integration simulation without vendor PLL/TMDS primitives:
// actual SPI RGB source + algorithm + original/result storage + real
// byte adapter + modeled x16 PSRAM + readback + unchanged quad cache.
module tb_final_rle_psram_quad;
    reg clk=1'b0, mem_clk=1'b0;
    always #18.5 clk = ~clk;      // ~27.0 MHz
    always #9.25 mem_clk = ~mem_clk; // ~54.0 MHz
    reg rst_n=1'b0;
    initial begin repeat(12) @(posedge clk); rst_n=1'b1; end

    wire flash_cs_n, flash_sclk, flash_mosi;
    wire flash_miso;
    wire [23:0] src_rgb;
    wire src_valid, src_frame_sent;
    wire [9:0] src_x;
    wire [8:0] src_y;
    wire src_pause, src_commit, orig_done;
    wire [23:0] algo_rgb;
    wire algo_valid, algo_frame_done;
    wire [9:0] algo_x;
    wire [8:0] algo_y;
    wire algo_rd_req, algo_rd_ready, algo_rd_valid;
    wire [23:0] algo_rd_addr;
    wire rd_req, rd_ready, rd_valid;
    wire [23:0] rd_addr;
    wire [7:0] rd_data;
    wire fill_rd_ready, fill_rd_valid;
    wire writer_pause, clear_done, store_done;
    wire orig_req, orig_ready;
    wire [23:0] orig_addr;
    wire [7:0] orig_data;

    final_spi_flash_rgb565_source #(.FLASH_BYTE_ADDR(24'h100000)) u_flash (
        .clk(clk), .rst_n(rst_n), .enable(clear_done), .pause(src_pause),
        .rgb(src_rgb), .valid(src_valid), .x(src_x), .y(src_y),
        .frame_sent(src_frame_sent),
        .flash_cs_n(flash_cs_n), .flash_sclk(flash_sclk),
        .flash_mosi(flash_mosi), .flash_miso(flash_miso)
    );
    // ROM is part of the FPGA .fs. There is no SPI device in this test.
    assign flash_miso = 1'b1;
    reg [7:0] expected_image[0:614399];
    initial $readmemh("image_data/test01_RGB565_BE_640x480.hex",expected_image);
    final_rgb565_store_frontend u_original (
        .clk(clk), .rst_n(rst_n), .clear_done(clear_done),
        .writer_pause(writer_pause), .src_valid(src_valid),
        .src_rgb(src_rgb), .src_x(src_x), .src_y(src_y),
        .src_pause(src_pause), .algorithm_valid(src_commit),
        .wr_req(orig_req), .wr_addr(orig_addr), .wr_data(orig_data),
        .wr_ready(orig_ready), .original_done(orig_done)
    );

    wire result_req, result_ready, overflow;
    wire [23:0] result_addr;
    wire [7:0] result_data;
    wire [31:0] clear_count, gray_count, gauss_count, edge_count;
    wire [7:0] mx_gray, mx_gauss, mx_edge;
    wire [7:0] gray, gauss, edge_px;
    wire gray_valid, gauss_valid, edge_valid;
    wire [9:0] gray_x, gauss_x, edge_x;
    wire [8:0] gray_y, gauss_y, edge_y;
    final_compute_store_top u_compute (
        .clk(clk), .rst_n(rst_n),
        .rgb_in(algo_rgb), .in_valid(algo_valid), .in_x(algo_x),
        .in_y(algo_y), .threshold(8'd80),
        .source_pause(writer_pause), .clear_done(clear_done),
        .store_done(store_done), .mem_wr_req(result_req),
        .mem_wr_addr(result_addr), .mem_wr_data(result_data),
        .mem_wr_ready(result_ready),
        .clear_write_count(clear_count), .gray_write_count(gray_count),
        .gauss_write_count(gauss_count), .edge_write_count(edge_count),
        .max_gray_fifo(mx_gray), .max_gauss_fifo(mx_gauss),
        .max_edge_fifo(mx_edge), .fifo_overflow(overflow),
        .dbg_gray(gray), .dbg_gray_valid(gray_valid),
        .dbg_gray_x(gray_x), .dbg_gray_y(gray_y),
        .dbg_gauss(gauss), .dbg_gauss_valid(gauss_valid),
        .dbg_gauss_x(gauss_x), .dbg_gauss_y(gauss_y),
        .dbg_edge(edge_px), .dbg_edge_valid(edge_valid),
        .dbg_edge_x(edge_x), .dbg_edge_y(edge_y)
    );
    wire mem_wr_req, mem_wr_ready;
    wire [23:0] mem_wr_addr;
    wire [7:0] mem_wr_data;
    final_psram_write_mux u_mux (
        .clk(clk), .rst_n(rst_n),
        .result_req(result_req), .result_addr(result_addr),
        .result_data(result_data), .result_ready(result_ready),
        .original_req(orig_req), .original_addr(orig_addr),
        .original_data(orig_data), .original_ready(orig_ready),
        .mem_req(mem_wr_req), .mem_addr(mem_wr_addr),
        .mem_data(mem_wr_data), .mem_ready(mem_wr_ready)
    );

    // Stage B: real original RGB reads from the SAME PSRAM model.
    final_psram_rgb_algorithm_source u_rgb_from_psram (
        .clk(clk), .rst_n(rst_n),
        .original_done(orig_done), .pause(writer_pause),
        .rd_req(algo_rd_req), .rd_addr(algo_rd_addr),
        .rd_req_ready(algo_rd_ready), .rd_valid(algo_rd_valid),
        .rd_data(rd_data), .rgb(algo_rgb), .valid(algo_valid),
        .x(algo_x), .y(algo_y), .frame_done(algo_frame_done)
    );
    wire rgb_cache_valid, gray_cache_valid, gauss_cache_valid, edge_cache_valid;
    wire [23:0] rgb_cache_data;
    wire [7:0] gray_cache_data, gauss_cache_data, edge_cache_data;
    wire [9:0] sample_x;
    wire [8:0] sample_y;
    wire fill_done;
    final_psram_cache_fill u_fill (
        .clk(clk), .rst_n(rst_n),
        .store_done(store_done), .original_done(orig_done),
        .rd_req(rd_req), .rd_addr(rd_addr), .rd_req_ready(fill_rd_ready),
        .rd_valid(fill_rd_valid), .rd_data(rd_data),
        .rgb_valid(rgb_cache_valid), .rgb_data(rgb_cache_data),
        .gray_valid(gray_cache_valid), .gray_data(gray_cache_data),
        .gauss_valid(gauss_cache_valid), .gauss_data(gauss_cache_data),
        .edge_valid(edge_cache_valid), .edge_data(edge_cache_data),
        .sample_x(sample_x), .sample_y(sample_y), .fill_done(fill_done)
    );

    assign fill_rd_ready = algo_frame_done && rd_ready;
    assign fill_rd_valid = algo_frame_done && rd_valid;
    assign algo_rd_ready = !algo_frame_done && rd_ready;
    assign algo_rd_valid = !algo_frame_done && rd_valid;
    wire combined_req = algo_frame_done ? rd_req : algo_rd_req;
    wire [23:0] combined_addr = algo_frame_done ? rd_addr : algo_rd_addr;
    wire phy_busy;
    wire [15:0] phy_rdata;
    wire phy_read,phy_write;
    wire [21:0] phy_addr;
    wire [15:0] phy_wdata;
    board_psram_byte_adapter u_adapter (
        .user_clk(clk), .user_resetn(rst_n),
        .wr_req(mem_wr_req), .wr_addr(mem_wr_addr),
        .wr_data(mem_wr_data), .wr_ready(mem_wr_ready),
        .rd_req(combined_req), .rd_addr(combined_addr),
        .rd_req_ready(rd_ready), .rd_valid(rd_valid), .rd_data(rd_data),
        .psram_clk(mem_clk), .psram_resetn(rst_n),
        .psram_busy(phy_busy), .psram_rdata(phy_rdata),
        .psram_read(phy_read), .psram_write(phy_write),
        .psram_addr(phy_addr), .psram_wdata(phy_wdata)
    );
    tb_psram_x16_memory u_memory (
        .clk(mem_clk), .rst_n(rst_n),
        .read(phy_read), .write(phy_write),
        .addr(phy_addr), .din(phy_wdata),
        .dout(phy_rdata), .busy(phy_busy)
    );

    reg [12:0] cache_rd_addr=13'd0;
    reg cache_rd_en=1'b0;
    wire [3:0] banks_ready;
    wire [15:0] cache_rgb;
    wire [7:0] cache_gray, cache_gauss, cache_edge;
    quad_frame_cache u_cache (
        .wr_clk(clk), .rd_clk(clk), .wr_resetn(rst_n), .rd_resetn(rst_n),
        .rgb_valid(rgb_cache_valid), .rgb_x(sample_x), .rgb_y(sample_y),
        .rgb_data(rgb_cache_data),
        .gray_valid(gray_cache_valid), .gray_x(sample_x), .gray_y(sample_y),
        .gray_data(gray_cache_data),
        .gauss_valid(gauss_cache_valid), .gauss_x(sample_x), .gauss_y(sample_y),
        .gauss_data(gauss_cache_data),
        .edge_valid(edge_cache_valid), .edge_x(sample_x), .edge_y(sample_y),
        .edge_data(edge_cache_data),
        .rd_addr(cache_rd_addr), .rd_en(cache_rd_en),
        .banks_ready(banks_ready),
        .rgb_rd(cache_rgb), .gray_rd(cache_gray),
        .gauss_rd(cache_gauss), .edge_rd(cache_edge)
    );

    reg [15:0] golden_rgb [0:4799];
    reg [7:0] golden_gray [0:4799];
    reg [7:0] golden_gauss [0:4799];
    reg [7:0] golden_edge [0:4799];
    integer flash_count = 0;
    integer input_count = 0;
    integer r, i, errors=0;
    integer expected_offset;
    reg [15:0] expected_pixel;
    reg [23:0] expanded_pixel;
    function [12:0] cache_index;
        input [9:0] xx;
        input [8:0] yy;
        begin cache_index = (yy >> 3)*80 + (xx >> 3); end
    endfunction
    initial begin
        for (i=0;i<4800;i=i+1) begin
            golden_rgb[i]=0;
            golden_gray[i]=0;
            golden_gauss[i]=0;
            golden_edge[i]=0;
        end
    end
    always @(posedge clk) if (rst_n) begin
        if (src_commit) flash_count = flash_count + 1;
        if (algo_valid) begin
            expected_offset = (algo_y*640 + algo_x)*2;
            expected_pixel = {expected_image[expected_offset],
                              expected_image[expected_offset+1]};
            expanded_pixel = {{expected_pixel[15:11], expected_pixel[15:13]},
                              {expected_pixel[10:5], expected_pixel[10:9]},
                              {expected_pixel[4:0], expected_pixel[4:2]}};
            if (algo_rgb !== expanded_pixel) begin
                $display("ERROR SPI image x=%0d y=%0d expected=%h got=%h",
                         algo_x,algo_y,expanded_pixel,algo_rgb);
                $fatal(1,"ROM+PSRAM image corrupted");
            end
            input_count = input_count + 1;
            if (algo_x[2:0]==0 && algo_y[2:0]==0)
                golden_rgb[cache_index(algo_x,algo_y)] <= expected_pixel;
        end
        if (gray_valid && gray_x[2:0]==0 && gray_y[2:0]==0)
            golden_gray[cache_index(gray_x,gray_y)] <= gray;
        if (gauss_valid && gauss_x[2:0]==0 && gauss_y[2:0]==0)
            golden_gauss[cache_index(gauss_x,gauss_y)] <= gauss;
        if (edge_valid && edge_x[2:0]==0 && edge_y[2:0]==0)
            golden_edge[cache_index(edge_x,edge_y)] <= edge_px;
        if (overflow) $fatal(1,"FIFO overflow");
    end

    initial begin : final_check
        wait (fill_done);
        repeat(10) @(negedge clk);
        if (banks_ready !== 4'b1111)
            $fatal(1,"Readback not complete in 4 banks: %b",banks_ready);
        if (input_count !== 307200 || flash_count !== 307200)
            $fatal(1,"Accepted ROM=%0d PSRAM-to-algorithm=%0d, each must be 307200",flash_count,input_count);
        if (clear_count !== 921600)
            $fatal(1,"PSRAM clear count %0d, expected 921600",clear_count);
        cache_rd_en=1'b1;
        for (r=0;r<4800;r=r+1) begin
            @(negedge clk); cache_rd_addr = r;
            @(negedge clk);
            if (cache_rgb !== golden_rgb[r] ||
                cache_gray !== golden_gray[r] ||
                cache_gauss !== golden_gauss[r] ||
                cache_edge !== golden_edge[r]) begin
                $display("MISMATCH sample[%0d]: RGB %h/%h Gray %h/%h Gauss %h/%h Edge %h/%h",
                         r, cache_rgb,golden_rgb[r],cache_gray,golden_gray[r],
                         cache_gauss,golden_gauss[r],cache_edge,golden_edge[r]);
                errors=errors+1;
                if (errors>12) $fatal(1,"Too many mismatches");
            end
        end
        if (errors==0)
            $display("PASS ROM+PSRAM+ALGORITHM+CACHE: 307200 ROM pixels, 4 PSRAM planes, 4800 cache pixels per plane");
        else $fatal(1,"Integrated pipeline mismatches=%0d",errors);
        $finish;
    end
    // Full 640x480 image transactions include 921600 clear writes,
    // 614400 original byte writes, 614400 original byte reads, and
    // three result planes.  A five-second timeout was insufficient.
    // Sparse progress messages make a genuine stall diagnosable.
    initial begin
        #(64'd5000000000);
        $display("PROGRESS 5s: cleared=%0d rom=%0d alg=%0d orig_done=%b result_done=%b fill_done=%b",
                 clear_count,flash_count,input_count,orig_done,store_done,fill_done);
        #(64'd5000000000);
        $display("PROGRESS 10s: cleared=%0d rom=%0d alg=%0d gray=%0d gauss=%0d edge=%0d orig_done=%b result_done=%b fill_done=%b",
                 clear_count,flash_count,input_count,gray_count,gauss_count,edge_count,
                 orig_done,store_done,fill_done);
        #(64'd10000000000);
        $display("PROGRESS 20s: cleared=%0d rom=%0d alg=%0d gray=%0d gauss=%0d edge=%0d orig_done=%b result_done=%b fill_done=%b",
                 clear_count,flash_count,input_count,gray_count,gauss_count,edge_count,
                 orig_done,store_done,fill_done);
        #(64'd10000000000);
        $fatal(1,"Timeout 30s: cleared=%0d rom=%0d alg=%0d gray=%0d gauss=%0d edge=%0d orig_done=%b result_done=%b fill_done=%b",
               clear_count,flash_count,input_count,gray_count,gauss_count,edge_count,
               orig_done,store_done,fill_done);
    end
endmodule

module tb_psram_x16_memory (
    input clk, rst_n, read, write,
    input [21:0] addr,
    input [15:0] din,
    output reg [15:0] dout,
    output reg busy
);
    reg [15:0] ram [0:2097151];
    reg pending;
    reg op_write;
    reg [21:0] latched_addr;
    reg [15:0] latched_data;
    reg [2:0] count;
    initial begin pending=0; busy=1; dout=0; count=0; end
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pending<=0; busy<=1'b1; dout<=0; count<=0;
        end else if (pending) begin
            if (count==0) begin
                if (op_write) ram[latched_addr>>1] <= latched_data;
                else dout <= ram[latched_addr>>1];
                busy<=1'b0;
                pending<=1'b0;
            end else count<=count-1'b1;
        end else if (read || write) begin
            pending<=1'b1;
            busy<=1'b1;
            count<=3'd2;
            op_write<=write;
            latched_addr<=addr;
            latched_data<=din;
        end else begin
            busy<=1'b0;
        end
    end
endmodule
