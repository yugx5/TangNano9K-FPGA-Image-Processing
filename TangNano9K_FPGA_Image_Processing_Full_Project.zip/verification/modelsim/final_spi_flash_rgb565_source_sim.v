`timescale 1ns / 1ps
// SIMULATION-ONLY behavioral image source; never add this file to Gowin synthesis.
// No external SPI Flash access. This is a drop-in replacement for the
// original final_spi_flash_rgb565_source module (ports unchanged).
// ROM output combines three 4096 x 4-bit blocks into a 12-bit RLE token.
// Each encoded run was computed from ORIGINAL 640x480 RGB565 bytes.
// The 3 x 4-bit ROM banks use synchronous reads and block_rom hints.
// Gowin loads the THREE HEX INITIALIZATION FILES during synthesis.
// These HEX files are build inputs, NOT external-board Flash data.
//
// IMPORTANT: The module name is retained for project compatibility; despite
// the external SPI Flash interface is not active.
// All downstream PSRAM/Gray/Gaussian/Sobel/HDMI logic is unchanged.
module final_spi_flash_rgb565_source #(
    parameter [23:0] FLASH_BYTE_ADDR = 24'h100000,
    parameter [1:0] HALF_DIV = 2'd1
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        enable,
    input  wire        pause,
    output wire [23:0] rgb,
    output wire        valid,
    output reg  [9:0]  x,
    output reg  [8:0]  y,
    output reg         frame_sent,
    output wire        flash_cs_n,
    output wire        flash_sclk,
    output wire        flash_mosi,
    input  wire        flash_miso
);
    // Do not drive any SPI activity while using the internal ROM source.
    assign flash_cs_n = 1'b1;
    assign flash_sclk = 1'b0;
    assign flash_mosi = 1'b0;

    localparam [2:0] ST_IDLE=3'd0, ST_LOAD=3'd1,
                     ST_STREAM=3'd2, ST_WAIT=3'd3, ST_DONE=3'd4;
    reg [2:0] state;
    reg [11:0] rom_addr;
    // Three native 4096 x 4-bit read-only memories.
    // Gowin GW1NR-9C BSRAM supports 4096 x 4. Explicit block_rom
    // attributes request BSRAM instead of a 49,152-LUT logic ROM.
    reg [3:0] rom_lo  [0:4095] /* synthesis syn_romstyle = "block_rom" */;
    reg [3:0] rom_mid [0:4095] /* synthesis syn_romstyle = "block_rom" */;
    reg [3:0] rom_hi  [0:4095] /* synthesis syn_romstyle = "block_rom" */;
    reg [3:0] rom_q_lo;
    reg [3:0] rom_q_mid;
    reg [3:0] rom_q_hi;
    wire [11:0] rom_q = {rom_q_hi, rom_q_mid, rom_q_lo};
    reg [8:0] run_left;
    reg [2:0] color_id;
    reg [15:0] pixel565;

    always @(*) begin
        case (color_id)
            3'd0: pixel565 = 16'h07FF;
            3'd1: pixel565 = 16'h18E3;
            3'd2: pixel565 = 16'h333C;
            3'd3: pixel565 = 16'h364A;
            3'd4: pixel565 = 16'hD986;
            3'd5: pixel565 = 16'hE646;
            3'd6: pixel565 = 16'hFFFF;
            default: pixel565 = 16'h0000;
        endcase
    end

    wire [4:0] r5 = pixel565[15:11];
    wire [5:0] g6 = pixel565[10:5];
    wire [4:0] b5 = pixel565[4:0];
    assign rgb = {{r5,r5[4:2]}, {g6,g6[5:4]}, {b5,b5[4:2]}};
    assign valid = (state == ST_STREAM) && enable && !frame_sent;

    // One synchronous read per 4-bit bank. No asynchronous ROM read
    // or reset on these outputs; this supports BSRAM ROM inference.
    always @(posedge clk) begin
        rom_q_lo  <= rom_lo[rom_addr];
        rom_q_mid <= rom_mid[rom_addr];
        rom_q_hi  <= rom_hi[rom_addr];
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= ST_IDLE;
            rom_addr <= 12'd0;
            run_left <= 9'd0;
            color_id <= 3'd0;
            x <= 10'd0;
            y <= 9'd0;
            frame_sent <= 1'b0;
        end else begin
            case (state)
                ST_IDLE: if (enable) begin
                    rom_addr <= 12'd0;
                    state <= ST_LOAD;  // rom_q already reads word 0
                end
                ST_LOAD: begin
                    color_id <= rom_q[2:0];
                    run_left <= rom_q[11:3];
                    state <= ST_STREAM;
                end
                ST_STREAM: if (valid && !pause) begin
                    if (x == 10'd639) begin
                        x <= 10'd0;
                        if (y == 9'd479) begin
                            frame_sent <= 1'b1;
                            state <= ST_DONE;
                        end else
                            y <= y + 1'b1;
                    end else
                        x <= x + 1'b1;

                    if (run_left > 9'd1)
                        run_left <= run_left - 1'b1;
                    else if (!(x == 10'd639 && y == 9'd479)) begin
                        rom_addr <= rom_addr + 1'b1;
                        state <= ST_WAIT; // allow next registered ROM word
                    end
                end
                ST_WAIT: state <= ST_LOAD;
                ST_DONE: begin
                    // Frame transmitted exactly once; no repeated pixels.
                end
                default: state <= ST_IDLE;
            endcase
        end
    end

    // The hex files are packaged with this .gprj. GowinSynthesis
    // resolves readmemh paths relative to the project file; ModelSim
    // test scripts run from that same project root.
    // These initialization bytes are built into the FPGA bitstream.
    initial begin
        $readmemh("src/integration/rle_rom_lo.hex", rom_lo);
        $readmemh("src/integration/rle_rom_mid.hex", rom_mid);
        $readmemh("src/integration/rle_rom_hi.hex", rom_hi);
    end
endmodule
