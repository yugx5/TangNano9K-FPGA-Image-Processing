# Run from ZIP project root in Questa/ModelSim Transcript:
# do verification/modelsim/run_quad_v2.do
if {![file exists work]} {vlib work}
vlog -sv -work work src/integration/quad_frame_cache.v src/integration/quad_video_source.v verification/tb/tb_quad_v2.v
vsim -voptargs=+acc work.tb_quad_v2
run -all
