# Start ModelSim from extracted ROM project root.
if {![file exists work]} {vlib work}
vlog -sv verification/modelsim/final_spi_flash_rgb565_source_sim.v verification/tb/tb_rle_rom_full_frame.v
vsim -voptargs=+acc work.tb_rle_rom_full_frame
run -all
