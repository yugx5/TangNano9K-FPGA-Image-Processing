# ROM pre-stored image integration simulation; run from root containing src/ and verification/.
# Fail fast if the image stimulus has not been extracted.
set _image_hex "image_data/test01_RGB565_BE_640x480.hex"
if {![file exists $_image_hex]} {
    error "IMAGE FILE MISSING: extract image_data/test01_RGB565_BE_640x480.hex into the source ROOT (same directory as src and verification), then retry."
}
if {[file size $_image_hex] < 614400} {
    error "IMAGE FILE TOO SHORT: expected 614400 RGB565 bytes expressed as HEX lines."
}
puts "IMAGE OK: $_image_hex"
# Run from the existing project ROOT (directory that contains src/).
# Integrated simulation test.
if {![file exists work]} {vlib work}
vlog -sv -work work \
    src/algorithm/rgb2gray.v \
    src/algorithm/line_buffer_3bank.v \
    src/algorithm/window3x3.v \
    src/algorithm/gaussian3x3_opt.v \
    src/algorithm/gaussian_pipeline_top.v \
    src/algorithm/sobel3x3_opt.v \
    src/algorithm/threshold8.v \
    src/algorithm/edge_pipeline_top.v \
    src/algorithm/frame_perf_counter.v \
    src/algorithm/rgb_edge_system_top.v \
    src/storage/frame_address_map.v \
    src/storage/pixel_stream_fifo.v \
    src/storage/final_result_store_writer.v \
    src/storage/final_compute_store_top.v \
    src/integration/board_psram_byte_adapter.v \
    src/integration/quad_frame_cache.v \
    verification/modelsim/final_spi_flash_rgb565_source_sim.v \
    src/integration/final_rgb565_store_frontend.v \
    src/integration/final_psram_rgb_algorithm_source.v \
    src/integration/final_psram_write_mux.v \
    src/integration/final_psram_cache_fill.v \
    verification/tb/tb_final_rle_psram_quad.v
vsim -voptargs=+acc work.tb_final_rle_psram_quad
run -all
